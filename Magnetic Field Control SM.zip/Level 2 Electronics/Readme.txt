
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * Level 2 electronics 2019-2021 Lukas Reichsoellner
 * Level 2 codes 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * m.borkowski@uva.nl

This folder contains the KiCAD project files for the electronics used in the Level 2 magnetic field stabilization scheme.

Folders:
 * Main: power supplies, ADC and DAC boards, galvanic isolation
 * Analog_front_end: an analog front-end (buffer) to be used to drive the ADCs with an asymmetric input signal
 * Extras: SPI line driver, autocalibration switch, LED display, magnetic field sensor mount (Solidworks project)

Any updated versions can be found on the project website www.strontiumbec.com and on github.com/StrontiumGroup
