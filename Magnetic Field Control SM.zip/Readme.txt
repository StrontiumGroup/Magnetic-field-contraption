
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * Level 2 electronics 2019-2021 Lukas Reichsoellner
 * Level 2 codes 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * m.borkowski@uva.nl

This Supplemental Material contains the schematics and source codes for the hardware and software used in the Level 2 magnetic field stabilization scheme. For updated versions of the codes and schematics visit www.strontiumbec.com and github.com/StrontiumGroup.
