/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <QSerialPortInfo>
#include <iostream>
#include <QTimer>
#include "arduinoconnection.h"

ArduinoConnection::ArduinoConnection()
{
    QTimer *watchdog = new QTimer(this);
    connect(watchdog, &QTimer::timeout, this, &ArduinoConnection::handleWatchdog);
    watchdog->start(500);
}

ArduinoConnection::~ArduinoConnection() {
    //close_port();
}

bool ArduinoConnection::find_arduino(QSerialPortInfo &spi) {
    for (auto &currentSpi : QSerialPortInfo::availablePorts()) {
        if (currentSpi.description() == "Arduino Due") {
            emit portStatus("Arduino found on " + spi.portName());
            spi = currentSpi;
            return true;
        }
    }
    emit portStatus("No Arduino found");
    return false;
}

bool ArduinoConnection::open_port(QSerialPortInfo spi) {
    port = new QSerialPort(spi);
    port->setBaudRate(QSerialPort::Baud9600);
    port->setDataBits(QSerialPort::DataBits::Data8);
    port->setStopBits(QSerialPort::StopBits::OneStop);
    port->setParity(QSerialPort::NoParity);
    port->setFlowControl(QSerialPort::FlowControl::NoFlowControl);
    if (! port->open(QSerialPort::ReadWrite)) {
        emit portStatus(port->portName() + " open fail: " + port->errorString());
        return false;
    } else {
        emit portStatus(port->portName() + " open successful");
        port->setRequestToSend(true); /* A must for the Due Native port */
        connect(port, &QSerialPort::readyRead, this, &ArduinoConnection::handleReadyRead);
        connect(port, &QSerialPort::errorOccurred, this, &ArduinoConnection::handleError);
        return true;
    }
}

void ArduinoConnection::close_port() {
    if (port != nullptr) {
        emit portStatus("Closing port");
        port->setRequestToSend(false);
        port->flush();
        delete port;
        port = nullptr;
    }
}

void ArduinoConnection::handleWatchdog() {
    if (need_restart) {
        QSerialPortInfo arduino_port;
        if (find_arduino(arduino_port)) {
            if (open_port(arduino_port)) need_restart = false;
        }
    }
}

void ArduinoConnection::handleReadyRead() {
    static int data_so_far = 0;
    static int data_kB = 0;
    const auto data = port->readAll();
    data_so_far += data.size();
    if (data_kB < data_so_far/1024) {
        emit portStatus("Data received " + QString::number(data_kB) + "kB");
        data_kB = data_so_far/1024;
    }

    emit dataReady(data);
}

void ArduinoConnection::handleError(QSerialPort::SerialPortError error) {
    if (error == QSerialPort::SerialPortError::NoError) return;
    emit portStatus("Serial error: " + port->errorString());
    need_restart = true;
}

void ArduinoConnection::send(QString what) {
    if (port) port->write((what + "\n").toStdString().c_str());
}
