/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "terminal.h"
#include "ui_terminal.h"

Terminal::Terminal(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::Terminal)
{
    ui->setupUi(this);
    /* Command entry */
    connect(ui->command, &QPlainTextEdit::textChanged,
            this, &Terminal::commandTextChanged);
}

void Terminal::commandTextChanged() {
    auto commandText = ui->command->toPlainText();
    if (commandText.contains(QChar(10)) || commandText.contains(QChar(13))) {
        commandText.remove(QChar(13));
        commandText.remove(QChar(10));
        emit sendCommand(commandText + "\n");
        ui->command->setPlainText("");
    }
}

void Terminal::toTerminal(QString text) {
    ui->terminal->insertPlainText(text);
    auto tc = ui->terminal->textCursor();
    tc.movePosition(QTextCursor::MoveOperation::End);
    ui->terminal->setTextCursor(tc);
}

Terminal::~Terminal()
{
    delete ui;
}
