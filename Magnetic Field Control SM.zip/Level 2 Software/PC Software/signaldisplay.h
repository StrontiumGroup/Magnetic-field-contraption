/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef SIGNALDISPLAY_H
#define SIGNALDISPLAY_H

#include <QFrame>
#include <qcustomplot.h>
#include "marquee.h"
#include "windowbuffer.h"

namespace Ui {
class SignalDisplay;
}

class SignalDisplay : public QFrame
{
    Q_OBJECT

public:
    explicit SignalDisplay(QWidget *parent = nullptr);
    ~SignalDisplay();
    void redraw();
    void setSignalTitle(QString title);
    void addSignal(double t, double y);

private:
    Ui::SignalDisplay *ui;
    const double sampleRate = 1000.0;
    QCPCurve *fastCurve = nullptr;
    QCPCurve *slowCurve = nullptr;
    static constexpr int slowSignalSamples = 2000;
    static constexpr int fastSignalSamples = 100;
    Marquee<double, slowSignalSamples> slowSignal;
    WindowBuffer<double, fastSignalSamples> fastSignal;

    const std::array<double, fastSignalSamples> fastSignalX = []() {
        std::array<double, fastSignalSamples> x;
        std::generate(x.begin(), x.end(), [n = 1] () mutable { return n++; });
        return x;
    }();

    const std::array<double, slowSignalSamples> slowSignalX = []() {
        std::array<double, slowSignalSamples> x;
        std::generate(x.begin(), x.end(), [n = 1] () mutable { return n++; });
        return x;
    }();

};

#endif // SIGNALDISPLAY_H
