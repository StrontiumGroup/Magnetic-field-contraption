/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef STAT_H
#define STAT_H

#include <numeric>
#include <algorithm>
#include <exception>
#include <array>

namespace stats {

template <typename Iterator>
auto mean(Iterator first, Iterator last)
{
    const auto len = std::distance(first, last);
    if (len == 0)
        throw std::runtime_error(
            "Cannot take a mean of zero elements");
    if (len == 1)
        return *first;
    return std::accumulate(first + 1, last, *first) / (1.0 * len);
}

template <typename Iterator>
auto var(Iterator first, Iterator last)
{
    const auto len = std::distance(first, last);
    if (len < 2)
        return 0.0;
    const auto mean_x = mean(first, last);
    const auto mean_x2 = std::inner_product(first, last, first, 0.0)
        / len;
    return (mean_x2 - mean_x * mean_x) * (1.0 * len / (len - 1));
}

template <class Iterator>
auto std(Iterator first, Iterator last)
{
    return sqrt(var(first, last));
}

} // namespace stat

#endif // STAT_H
