/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "sequencedisplaycontrol.h"
#include "ui_sequencedisplaycontrol.h"

SequenceDisplayControl::SequenceDisplayControl(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::SequenceDisplayControl)
{
    ui->setupUi(this);
}

SequenceDisplayControl::~SequenceDisplayControl()
{
    delete ui;
}

void SequenceDisplayControl::connectWithDisplay(SequenceDisplay &sequenceDisplay)
{
    connect(ui->horizontalCursorOn, &QCheckBox::stateChanged, &sequenceDisplay, &SequenceDisplay::showHorizontalCursor);
    connect(ui->horizontalCursorOn, &QCheckBox::stateChanged, ui->horizontalCursorPos, [&, this](bool active) {ui->horizontalCursorPos->setDisabled(!active);});
    connect(ui->verticalCursorOn, &QCheckBox::stateChanged, &sequenceDisplay, &SequenceDisplay::showVerticalCursor);
    connect(ui->verticalCursorOn, &QCheckBox::stateChanged, ui->verticalCursorPos, [&, this](bool active) {ui->verticalCursorPos->setDisabled(!active);});
    connect(ui->horizontalCursorPos, QOverload<double>::of(&QDoubleSpinBox::valueChanged), &sequenceDisplay, &SequenceDisplay::setHorizontalCursorPosition);
    connect(ui->verticalCursorPos, QOverload<double>::of(&QDoubleSpinBox::valueChanged), &sequenceDisplay, &SequenceDisplay::setVerticalCursorPosition);
    ui->horizontalCursorOn->setChecked(false);
    ui->verticalCursorOn->setChecked(false);
    connect(ui->showLegend, &QCheckBox::stateChanged, &sequenceDisplay, &SequenceDisplay::setShowLegend);
    ui->showLegend->setChecked(false);
    connect(ui->zoomhorizontal, &QCheckBox::stateChanged, &sequenceDisplay, &SequenceDisplay::setEnableZoomHorizontal);
    connect(ui->zoomvertical, &QCheckBox::stateChanged, &sequenceDisplay, &SequenceDisplay::setEnableZoomVertical);
    ui->zoomhorizontal->setChecked(true);
    ui->zoomvertical->setChecked(true);
    connect(&sequenceDisplay, &SequenceDisplay::updateCursorStep, this, [&, this](double horizontalZoomStep, double verticalZoomStep)
    {
        ui->horizontalCursorPos->setSingleStep(horizontalZoomStep);
        ui->verticalCursorPos->setSingleStep(verticalZoomStep);
    });
    connect(ui->onlyShowMainSequence, &QCheckBox::clicked, &sequenceDisplay, &SequenceDisplay::setOnlyShowMainSequence);
    connect(ui->adjustViewOnNewSequence, &QCheckBox::clicked, &sequenceDisplay, &SequenceDisplay::setAdjustViewOnNewSequence);
    connect(ui->saveSensorSignals, &QCheckBox::clicked, &sequenceDisplay, &SequenceDisplay::setSaveSensorSignalsToFile);
    connect(ui->saveControlSequence, &QCheckBox::clicked, &sequenceDisplay, &SequenceDisplay::setSaveControlSequenceToFile);
    connect(ui->filenamePrefix, &QLineEdit::textChanged, &sequenceDisplay, &SequenceDisplay::setFilenamePrefix);
    connect(ui->goToFullSequenceView, &QPushButton::pressed, &sequenceDisplay, &SequenceDisplay::goToFullView);

}

