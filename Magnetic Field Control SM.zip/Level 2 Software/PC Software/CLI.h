/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef CLI_H
#define CLI_H

#include <sstream>
#include <functional>
#include <vector>

#define MAX_COMMAND_LENGTH 2000
#define MAX_PARAMETERS 200

#define VARTYPE_INT 0
#define VARTYPE_DOUBLE 1

#define MAX_ARRAY_LENGTH 100


#define CLILambda(function_body) \
    *new std::function<void(int, char**)> \
    ([&, this](int argc, char **argv) {function_body})

#define CLIMember(member_function_name) \
    CLILambda({member_function_name(argc, argv);})

#define cli_stdin 0
#define cli_stdout 1
#define cli_stderr 2
#define cli_debug 3

struct command_def {
  const char *name;
  const char *description;
  const char *help;
  std::function<void(int, char **)> fun_ptr;
};

struct variable_def {
  const char *name;
  const char *description;
  int  vartype;
  void *ptr;
};

struct array_def {
  const char *name;
  const char *description;
  int vartype;
  int length;
  void *ptr;
};

class CLIent;

class CLI
{
public:
    CLI();

    CLI(
        std::function<const char *(void)> cli_prompt_func,
        std::function<const char *(void)> cli_getline,
        std::function<int(const char *, int dest)> cli_fputs
    );

    virtual ~CLI();

    std::vector<struct command_def> commands;
    std::vector<struct variable_def> variables;
    std::vector<struct array_def> arrays;

    void loop();

    int find_command(char *name);
    int command_num, variable_num, array_num;
    void execute_command(const char *str);
    void register_client(CLIent &client);
    int register_array(struct array_def the_array);
    int register_variable(struct variable_def the_variable);
    int register_command(struct command_def the_command);
    int arraylen(const char *arrayname);
    int setarraylen(const char *arrayname, int len);
    void print_variable(int i);
    int find_variable(char *name);
    int find_array(const char *name);
    char *create_name(const char *format, ...);
    int cli_fprintf(int dest, const char *fmt, ...);
    int cli_fputs_builtin(const char *buf, int dest);
    int read_double(const char *str, double *target);
    int read_double_in_range(const char *str, double *target, double range_min, double range_max);
    int read_int(const char *str, int *target);
    int read_int_in_range(const char *str, int *target, int range_min, int range_max);
    std::function<const char *(void)> cli_prompt_func;
    std::function<const char *(void)> cli_getline;
    std::function<int(const char *s, int dest)> cli_fputs;

protected:

private:
    void register_builtins();

};

class CLIent {
public:
    CLIent(CLI &cli);
    void register_with_cli();
    CLI &cli;

};

#endif // CLI_H
