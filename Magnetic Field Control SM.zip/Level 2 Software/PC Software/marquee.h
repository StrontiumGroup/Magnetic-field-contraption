/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef MARQUEE_H
#define MARQUEE_H

#include <algorithm>
#include <array>

template <typename Number, size_t buffer_len>
class Marquee {
public:
    Marquee()
    {
        static_assert(buffer_len > 0,
            "Marquee must have at least 1 element");
        std::fill(buffer.begin(), buffer.end(), 0);
    }

    void store(Number x)
    {
        std::rotate(buffer.begin(),
            buffer.begin() + 1,
            buffer.end());
        buffer.back() = x;
    }

    [[nodiscard]] auto begin()
    {
        return buffer.begin();
    }

    [[nodiscard]] auto end()
    {
        return buffer.end();
    }

private:
    std::array<Number, buffer_len> buffer;
};

#endif // MARQUEE_H
