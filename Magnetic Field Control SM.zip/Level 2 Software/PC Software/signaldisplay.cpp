/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "signaldisplay.h"
#include "colors.h"
#include "ui_signaldisplay.h"
#include <algorithm>
#include <numeric>
#include <utility>

SignalDisplay::SignalDisplay(QWidget* parent)
    : QFrame(parent)
    , ui(new Ui::SignalDisplay)
{
    ui->setupUi(this);

    auto setup_axis = [&](auto axis) {
        axis->setTickLabelColor(fg_color);
        axis->setBasePen(QPen(fg_color));
        axis->setLabelColor(fg_color);
        axis->setTickPen(QPen(fg_color));
        axis->setSubTickPen(QPen(dim(fg_color)));
        axis->grid()->setVisible(true);
        axis->grid()->setSubGridVisible(false);
        axis->grid()->setPen(QPen(dim(fg_color)));
        axis->grid()->setSubGridPen(QPen(dim(dim(fg_color))));
    };

    for (auto& plot : { ui->fastDisplay, ui->slowDisplay }) {
        plot->setBackground(bg_color);
        plot->axisRect()->setupFullAxesBox();
        for (auto& axis :
            { plot->xAxis, plot->yAxis, plot->xAxis2, plot->yAxis2 })
            setup_axis(axis);
    }

    auto setup_curve
        = [&](auto& curve, auto color, auto fillcolor, auto plot) {
              curve = new QCPCurve(plot->xAxis, plot->yAxis);
              curve->setPen(QPen(color));
              curve->setLineStyle(QCPCurve::LineStyle::lsLine);
          };

    setup_curve(
        fastCurve, main_color, dim(main_color), ui->fastDisplay);

    setup_curve(
        slowCurve, main_color, dim(main_color), ui->slowDisplay);

    //slowCurve->setLineStyle(QCPCurve::LineStyle::lsNone);
    //slowCurve->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssDot, 4));
}

SignalDisplay::~SignalDisplay() { delete ui; }

void SignalDisplay::redraw()
{
    const auto mean = fastSignal.mean();
    const auto stdev = fastSignal.std();

    fastCurve->setData(
        QVector<double>(fastSignalX.begin(), fastSignalX.end()),
        QVector<double>(fastSignal.begin(), fastSignal.end()));
    ui->fastDisplay->xAxis->setRange(QCPRange(1, fastSignalSamples));
    ui->fastDisplay->yAxis->setRange(QCPRange(mean - 0.0006, mean + 0.0006));
    ui->fastDisplay->axisRect()->setupFullAxesBox();

    ui->fastDisplay->replot(
        QCustomPlot::RefreshPriority::rpQueuedReplot);
    ui->meanLabel->setText(
        "Mean " + QString::number(mean, 'f', 6) + " G");
    ui->stdevLabel->setText(
        "StDev " + QString::number(stdev, 'f', 6) + " G");

    slowCurve->setData(
        QVector<double>(slowSignalX.begin(), slowSignalX.end()),
        QVector<double>(slowSignal.begin(), slowSignal.end()));
    ui->slowDisplay->xAxis->setRange(QCPRange(1, slowSignalSamples));
    ui->slowDisplay->yAxis->setRange(QCPRange(
        *std::min_element(slowSignal.begin(), slowSignal.end()),
        *std::max_element(slowSignal.begin(), slowSignal.end())));
    ui->slowDisplay->axisRect()->setupFullAxesBox();
    ui->slowDisplay->replot(
        QCustomPlot::RefreshPriority::rpQueuedReplot);
}

void SignalDisplay::addSignal([[maybe_unused]] double t, double y)
{
    fastSignal.store(y);
    slowSignal.store(y);
}

void SignalDisplay::setSignalTitle(QString title)
{
    ui->displayTitle->setText(title);
}
