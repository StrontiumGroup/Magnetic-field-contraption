/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef SEQUENCEDISPLAY_H
#define SEQUENCEDISPLAY_H

#include <QWidget>
#include <qcustomplot.h>
#include <vector>

//#include <CLI.h>

/*

typedef struct {
    double x1, x2, y1, y2;
} lockrect;

*/

class CLI;

namespace Ui {
class SequenceDisplay;
}

class SequenceDisplay : public QFrame
{
    Q_OBJECT

public:
    explicit SequenceDisplay(QWidget *parent = nullptr);
    ~SequenceDisplay();

    void registerWithCLI(CLI &CLI);
    void updateSignals(double t, double main_y, double aux_y);

public slots:
    void setSequencePosition(double position);
    void redraw();
    void resetPlotRanges();
    void showHorizontalCursor(bool OnOff);
    void showVerticalCursor(bool OnOff);
    void setHorizontalCursorPosition(double position);
    void setVerticalCursorPosition(double position);
    void setShowLegend(bool OnOff);
    void setEnableZoomHorizontal(bool OnOff);
    void setEnableZoomVertical(bool OnOff);
    void setOnlyShowMainSequence(bool OnOff);
    void setAdjustViewOnNewSequence(bool OnOff);
    void setSaveSensorSignalsToFile(bool OnOff);
    void setSaveControlSequenceToFile(bool OnOff);
    void setFilenamePrefix(QString filenamePrefix);
    void goToFullView();

signals:
    void updated();
    void updateSeriesNr(QString series_nr, QString run_nr);
    void updateCursorStep(double horizontalCursorStep, double verticalCursorStep);

private:
    Ui::SequenceDisplay *ui;
    void setupPlot();

    std::vector<double> tData = {};
    std::vector<double> offsetData = {};
    std::vector<double> setpointData = {};
    std::vector<bool> lockedData = {};
    std::vector<double> main_t = {};
    std::vector<double> main_y = {};
    std::vector<double> aux_t = {};
    std::vector<double> aux_y = {};

    bool record = false;
    bool inMainSequence = false;
    bool showOnlyMainSequence = true;
    bool adjustViewOnNewSequence = true;

    bool zoomHorizontal = true;
    bool zoomVertical = true;
    double horizontalCursorPosition = 0.0;
    double verticalCursorPosition = 0.0;
    bool saveControlSequenceToFile = false;
    bool saveSensorSignalsToFile = false;
    QString filenamePrefix = "";

    QCPCurve *offset, *setpoint, *locks;
    QCPCurve *position_indicator;
    QCPCurve *main, *aux, *old_main, *old_aux;
    QCPCurve *horizontalcursor;
    QCPCurve *verticalcursor;

    Qt::Orientations zoomOrientations = Qt::Horizontal | Qt::Vertical;
//    std::vector <lockrect> lockrects = {};
//    std::vector <QCPItemRect *> lockrect_boxes = {};
};

#endif // SEQUENCEDISPLAY_H
