/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "controlconnection.h"
#include <QMessageBox>
#include <QTcpSocket>
#include <iostream>

ControlConnection::ControlConnection()
{
    start_listening();
    connect(&tcp_server, &QTcpServer::newConnection, this, &ControlConnection::handleIncomingConnection);
}

void ControlConnection::handleIncomingConnection() {
    if (conn != nullptr) {
        tcp_server.nextPendingConnection()->close();
    } else {
        const auto new_conn = tcp_server.nextPendingConnection();
        //if (new_conn->peerAddress()) // later
        conn = new_conn;
        connect(conn, &QTcpSocket::readyRead, this, &ControlConnection::handleReadyRead);
        connect(conn, &QTcpSocket::disconnected, this, &ControlConnection::handleError);
        connect(conn, &QTcpSocket::errorOccurred, this, &ControlConnection::handleError);
        tcp_server.pauseAccepting();
        emit updateStatus("Connection from " + conn->peerAddress().toString());
    }
}

void ControlConnection::handleReadyRead() {
    static QByteArray line = "";
    const auto data = conn->readAll();
    for (char c : data) {
        if (c == 10 || c == 13) {
            if (line.length() > 0) {
                emit received(line);
                line = "";
            }
        } else {
            line += c;
        }
    }
}

void ControlConnection::handleError() {
    if (conn != nullptr) {
        disconnect(conn);
        conn = nullptr;
    }
    tcp_server.resumeAccepting();
    emit updateStatus("Disconnected");
}

void ControlConnection::updateControlIP(QString control_ip) {

}

void ControlConnection::updateControlPort(int new_port) {
    control_port = new_port;
    start_listening();
}

void ControlConnection::start_listening() {
    if (tcp_server.isListening()) tcp_server.close();
    if (!tcp_server.listen(QHostAddress::Any, control_port)) {
        tcp_server.close();
        emit updateStatus("Error: could not listen on port " + QString::number(control_port));
    } else {
        emit updateStatus("Awaiting connections on port " + QString::number(control_port));
    }
}

void ControlConnection::send(QString data) {
    if (conn != nullptr) {
        conn->write(data.toStdString().c_str());
    }
}
