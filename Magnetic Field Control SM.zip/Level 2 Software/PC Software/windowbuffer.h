/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef WINDOWBUFFER_H
#define WINDOWBUFFER_H

#include <algorithm>
#include <vector>
#include <stats.h>

template <typename Number, size_t buffer_len>
class WindowBuffer {
public:
    WindowBuffer()
    {
        static_assert(buffer_len >= 2,
            "WindowBuffer must have at least 2 elements");
        std::fill(stored_buffer.begin(), stored_buffer.end(), 0);
    }

    void store(Number x)
    {
        input_buffer[input_pos] = x;
        ++input_pos;
        if (input_pos == buffer_len) {
            stored_buffer = input_buffer;
            input_pos = 0;
            _mean = stats::mean(stored_buffer.begin(),
                stored_buffer.end());
            _std = stats::std(stored_buffer.begin(),
                stored_buffer.end());
        }
    }

    [[nodiscard]] const auto begin() { return stored_buffer.begin(); }

    [[nodiscard]] const auto end() { return stored_buffer.end(); }

    [[nodiscard]] const Number mean() { return _mean; }

    [[nodiscard]] const Number std() { return _std; }

private:
    std::array<Number, buffer_len> input_buffer;
    std::array<Number, buffer_len> stored_buffer;
    Number _mean = 0;
    Number _std = 0;
    size_t input_pos = 0;
};
#endif // WINDOWBUFFER_H
