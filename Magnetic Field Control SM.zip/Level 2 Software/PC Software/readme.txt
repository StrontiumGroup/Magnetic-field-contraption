
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * Code 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * m.borkowski@uva.nl

This folder contains the PC monitoring code that also allows relaying commands to the Arduino controller at high speed over the native USB connector on the Arduino Due. To this end the monitor opens a listening TCP/IP port. The code can be built using Qt Creator with Qt 5 or Qt 6 installed. The software is meant to be run on Windows 10.

