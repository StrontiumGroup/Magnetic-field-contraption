/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <iostream>

#include "colors.h"
#include <QKeyEvent>
#include <QSettings>
#include <QTimer>

MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , settings("Mateusz", "MFCC")
{
    ui->setupUi(this);

    ui->mainSensor->setSignalTitle("M A I N   S E N S O R");
    ui->auxSensor->setSignalTitle("A U X   S E N S O R");

    arduinoConnection.moveToThread(&arduinoConnectionThread);
    arduinoConnectionThread.start(QThread::TimeCriticalPriority);

    /* Arduino connection status bar */
    connect(&arduinoConnection, &ArduinoConnection::portStatus, this,
        &MainWindow::getPortStatus);

    /* Data from Arduino to decoder */
    connect(&arduinoConnection, &ArduinoConnection::dataReady,
        &mfcDecoder, &MFCDecoder::decode_chunk);

    /* Decoded terminal data to main window */
    connect(&mfcDecoder, &MFCDecoder::terminalUpdated,
        ui->terminalWidget, &Terminal::toTerminal);

    /* Send commands from terminal command line to Arduino and also
     * interpret them here */
    connect(ui->terminalWidget, &Terminal::sendCommand,
        &arduinoConnection, &ArduinoConnection::send);
    connect(ui->terminalWidget, &Terminal::sendCommand, this,
        &MainWindow::controlCommand);

    /* Control connection status */
    connect(&controlConnection, &ControlConnection::updateStatus, this,
        &MainWindow::getControlStatus);

    /* Set control port */
    connect(ui->control_port,
        QOverload<int>::of(&QSpinBox::valueChanged), &controlConnection,
        &ControlConnection::updateControlPort);
    ui->control_port->setValue(
        settings.value("control_port", 8784).toInt());

    /* Set control IP (for security) */
    connect(ui->control_ip, &QLineEdit::textChanged, &controlConnection,
        &ControlConnection::updateControlIP);
    ui->control_ip->setText(
        settings.value("control_ip", "127.0.0.1").toString());

    /* Relay commands from Control on TCP/IP to MFC on USB */
    connect(&controlConnection, &ControlConnection::received,
        &arduinoConnection, &ArduinoConnection::send);

    /* Interpret commands from Control in this program too */
    connect(&controlConnection, &ControlConnection::received, this,
        &MainWindow::controlCommand);

    /* Fullscreen toggle */
    connect(ui->toggle_fullscreen, &QPushButton::pressed, this,
        &MainWindow::toggleFullscreen);

    /* Plot refresh */
    connect(
        &redrawTimer, &QTimer::timeout, this, &MainWindow::redrawAll);
    redrawTimer.start(30);

    /* L O C K   O N  sign */
    connect(&mfcDecoder, &MFCDecoder::lockStatus, this,
        [&, this](bool isLocking) {
            static bool state = this->ui->lockOn->isVisible();
            if (state != isLocking) {
                this->ui->lockOn->setVisible(isLocking);
                state = isLocking;
            }
        });

    /* Processor use */
    connect(&mfcDecoder, &MFCDecoder::processorUse, ui->processorUse,
        &QProgressBar::setValue);
    ui->sequenceDisplay->registerWithCLI(cli);

    /* Position indicator */
    connect(&mfcDecoder, &MFCDecoder::sequencePosition,
        ui->sequenceDisplay, &SequenceDisplay::setSequencePosition);

    /* Series and run nr */
    connect(ui->sequenceDisplay, &SequenceDisplay::updateSeriesNr, this,
        &MainWindow::updateSeriesNr);

    /* Sequence data to sequenceDisplay and the two signalDisplays */
    connect(&mfcDecoder, &MFCDecoder::updateSignals, this,
        [&, this](double t, double main, double aux) {
            ui->mainSensor->addSignal(t, main);
            ui->auxSensor->addSignal(t, aux);
            ui->sequenceDisplay->updateSignals(t, main, aux);
        });

    /* Sequence display control to sequence display */
    ui->sequenceDisplayControl->connectWithDisplay(
        *ui->sequenceDisplay);
}

void MainWindow::updateSeriesNr(QString series, QString run_nr)
{
    ui->series_nr->setText(series);
    ui->run_nr->setText(run_nr);
}

MainWindow::~MainWindow()
{
    settings.setValue("control_port", ui->control_port->value());
    settings.setValue("control_ip", ui->control_ip->text());

    delete ui;
}

void MainWindow::getPortStatus(QString status)
{
    ui->port_status->setText(status);
}

void MainWindow::controlCommand(QString cmd)
{
    cli.execute_command(cmd.toStdString().c_str());
}

void MainWindow::getControlStatus(QString status)
{
    ui->control_status->setText(status);
}

void MainWindow::toggleFullscreen()
{
    if (isFullScreen()) {
        setWindowState(Qt::WindowMaximized);
    } else {
        setWindowState(Qt::WindowFullScreen);
    }
}

void MainWindow::redrawAll()
{
    ui->sequenceDisplay->redraw();
    ui->mainSensor->redraw();
    ui->auxSensor->redraw();
}
