/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <CLI.h>

#include "sequencedisplay.h"
#include "ui_sequencedisplay.h"
#include "colors.h"

SequenceDisplay::SequenceDisplay(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::SequenceDisplay)
{
    ui->setupUi(this);

    setupPlot();
    connect(this, &SequenceDisplay::updated, this, [&, this]() {
        if (adjustViewOnNewSequence) resetPlotRanges();
    });

    connect(ui->plot, &QCustomPlot::mouseWheel, this, [&, this]() {
        const double relativeStep = 0.02;
        emit updateCursorStep(
            relativeStep * (ui->plot->yAxis->range().upper - ui->plot->yAxis->range().lower),
            relativeStep * (ui->plot->xAxis->range().upper - ui->plot->xAxis->range().lower));
    });

}

SequenceDisplay::~SequenceDisplay()
{
    delete ui;
}

void SequenceDisplay::registerWithCLI(CLI &cli)
{
    cli.register_command({
        .name =
            "seq0.data.t",
        .description =
            "",
        .help =
            "",
        .fun_ptr = CLILambda(
        {
            if (!inMainSequence) return;
            tData.clear();
            for (int i = 1; i < argc; i ++) {
                tData.push_back(atof(argv[i]));
            }
            if (record) emit updated();
        })
    });

    cli.register_command({
        .name =
            "seq0.data.a0",
        .description =
            "",
        .help =
            "",
        .fun_ptr = CLILambda(
        {
            if (!inMainSequence) return;
            offsetData.clear();
            for (int i = 1; i < argc; i ++) {
                offsetData.push_back(atof(argv[i]));
            }
            if (record) emit updated();
        })
    });

    cli.register_command({
        .name =
            "seq0.data.a1",
        .description =
            "",
        .help =
            "",
        .fun_ptr = CLILambda(
        {
            if (!inMainSequence) return;
            setpointData.clear();
            for (int i = 1; i < argc; i ++) {
                setpointData.push_back(atof(argv[i]));
            }
            if (record) emit updated();
        })
    });

    cli.register_command({
        .name =
            "seq0.data.d0",
        .description =
            "",
        .help =
            "",
        .fun_ptr = CLILambda(
        {
            if (!inMainSequence) return;
            lockedData.clear();
            for (int i = 1; i < argc; i ++) {
                lockedData.push_back(atof(argv[i]) > 0.5 ? true : false);
            }
            if (record) emit updated();
        })
    });

    cli.register_command({
        .name =
            "file",
        .description =
            "",
        .help =
            "",
        .fun_ptr = CLILambda(
        {
            if (argc == 1) {
                emit updateSeriesNr("---", "---");
                record = false;
                inMainSequence = false;
            }
            if (argc == 2) {
                emit updateSeriesNr("---", argv[1]);
                record = true;
                inMainSequence = true;
                main_t = main_y = aux_t = aux_y = {};
            }
            if (argc == 3) {
                emit updateSeriesNr(argv[1], argv[2]);
                record = true;
                inMainSequence = true;
                main_t = main_y = aux_t = aux_y = {};
            }
        })
    });

}

void SequenceDisplay::setupPlot() {
    ui->plot->setBackground(bg_color);

    auto setup_axis = [&](auto axis) {
        axis->setTickLabelColor(fg_color);
        axis->setBasePen(QPen(fg_color));
        axis->setLabelColor(fg_color);
        axis->setTickPen(QPen(fg_color));
        axis->setSubTickPen(QPen(dim(fg_color)));
        axis->grid()->setVisible(true);
        axis->grid()->setSubGridVisible(true);
        axis->grid()->setPen(QPen(dim(fg_color)));
        axis->grid()->setSubGridPen(QPen(dim(dim(fg_color))));
        axis->setLabelFont(QFont("Segoe UI Light"));
    };

    for (auto &axis : {ui->plot->xAxis, ui->plot->yAxis, ui->plot->xAxis2, ui->plot->yAxis2})
        setup_axis(axis);

    ui->plot->xAxis->setRange(0.0, 30.0);
    ui->plot->xAxis->setLabel("T I M E   ( S )");
    ui->plot->yAxis->setLabel("C U R R E N T   ( A )  /  M A G N E T I C   F I E L D   ( G )");
    ui->plot->setInteraction(QCP::iRangeDrag, true);
    ui->plot->setInteraction(QCP::iRangeZoom, true);

    auto setup_curve = [&, this](auto &curve, auto color, auto fillcolor, auto legendTitle) {
        curve = new QCPCurve(ui->plot->xAxis, ui->plot->yAxis);
        curve->setPen(QPen(color));
        curve->setLineStyle(QCPCurve::LineStyle::lsLine);
        curve->setScatterStyle(QCPScatterStyle(QCPScatterStyle::ssCircle,color, fillcolor, 5));
        if (legendTitle != "") {
            curve->setName(legendTitle);
        } else {
            curve->removeFromLegend();
        }
    };

    setup_curve(locks, lock_color, dim(lock_color), "");
    setup_curve(offset, offset_color, dim(offset_color), "Current offset (A)");
    setup_curve(setpoint, setpoint_color, dim(setpoint_color), "Magnetic field setpoint (G)");
    setup_curve(horizontalcursor, setpoint_color, dim(setpoint_color), "");
    setup_curve(verticalcursor, setpoint_color, dim(setpoint_color), "");

    locks->setPen(QPen(lock_color,1,Qt::DashLine));
    locks->setBrush(lock_bg_color);

    horizontalcursor->setPen(QPen(lock_color,1,Qt::DashLine));
    verticalcursor->setPen(QPen(lock_color,1,Qt::DashLine));
    verticalcursor->removeFromLegend();

    position_indicator = new QCPCurve(ui->plot->xAxis, ui->plot->yAxis);
    position_indicator->setPen(QPen(lock_color));
    position_indicator->removeFromLegend();

    main = new QCPCurve(ui->plot->xAxis, ui->plot->yAxis);
    main->setPen(QPen(main_color));
    main->setName("Main sensor signal (G)");

    aux = new QCPCurve(ui->plot->xAxis, ui->plot->yAxis);
    aux->setPen(QPen(aux_color));
    aux->setName("Aux sensor signal (G)");


    ui->plot->legend->setBrush(bg_color);
    ui->plot->legend->setTextColor(main_color);
}

void SequenceDisplay::redraw() {
    auto setData = [&](QCPCurve *curve, std::vector<double> &data_x, std::vector<double> &data_y)
    {
        curve->setData(
            QVector<double>(data_x.begin(), data_x.end()),
            QVector<double>(data_y.begin(), data_y.end())
        );
    };

    setData(offset, tData, offsetData);
    setData(setpoint, tData, setpointData);
    setData(main, main_t, main_y);
    setData(aux, aux_t, aux_y);

    /* Converts the sequence of locks/unlocks into a staircase-shaped curve */
    auto setLockData = [&](QCPCurve *curve, std::vector<double> &t, std::vector<bool> &locked)
    {
        std::vector<double> t2 = {}, l2 = {};
        if (locked.size() == t.size() && locked.size() > 0) {
            for (size_t i = 0; i < t.size() - 1; i ++) {
                t2.push_back(t.at(i));
                t2.push_back(t.at(i+1));
                t2.push_back(t.at(i+1));
                l2.push_back(locked.at(i) ? 15.0 : -15.0);
                l2.push_back(locked.at(i) ? 15.0 : -15.0);
                l2.push_back(locked.at(i+1) ? 15.0 : -15.0);
            }
        }
        setData(curve, t2, l2);
    };
    setLockData(locks, tData, lockedData);

    ui->plot->replot(QCustomPlot::RefreshPriority::rpImmediateRefresh);
/*    static bool once = true;
    if (once) {
        once = false;
        lockrects = sv.get_lock_rects();
        for (auto &lockrect : lockrects) {
            QCPItemRect *rect = new QCPItemRect(ui->plot);
            rect->topLeft     ->setType(QCPItemPosition::ptPlotCoords);
            rect->topLeft     ->setCoords(lockrect.x1, +20.0);

            rect->bottomRight ->setType(QCPItemPosition::ptPlotCoords);
            rect->bottomRight ->setCoords(lockrect.x2, -20.0);

            rect->setBrush(QBrush(QColor(0, 128, 255, 128)));
            rect->setSelectable(true);
            rect->setVisible(false);
            lockrect_boxes.push_back(rect);
        }
    }*/
}

void SequenceDisplay::setSequencePosition(double position)
{
    position_indicator->setData({position, position}, {-100.0, 100.0});
}

void SequenceDisplay::resetPlotRanges()
{
    if (tData.size() >= 2) {
        const double t_start = tData.front();
        const double t_end = tData.back();
        if (t_end > t_start) {
            ui->plot->xAxis->setRange(t_start, t_end);
            ui->plot->yAxis->setRange(-10, 10);
        }
    }
}

void SequenceDisplay::showHorizontalCursor(bool OnOff)
{
    horizontalcursor->setVisible(OnOff);
}

void SequenceDisplay::showVerticalCursor(bool OnOff)
{
    verticalcursor->setVisible(OnOff);
}

void SequenceDisplay::setHorizontalCursorPosition(double position) {
    horizontalcursor->setData({-100.0, +1000.0}, {position, position});
}

void SequenceDisplay::setVerticalCursorPosition(double position) {
    verticalcursor->setData({position, position}, {-100.0, +100.0});
}

void SequenceDisplay::setShowLegend(bool setting) {
    ui->plot->legend->setVisible(setting);
}

void SequenceDisplay::setEnableZoomHorizontal(bool setting) {
    zoomOrientations.setFlag(Qt::Horizontal, setting);
    ui->plot->axisRect()->setRangeZoom(zoomOrientations);
}

void SequenceDisplay::setEnableZoomVertical(bool setting) {
    zoomOrientations.setFlag(Qt::Vertical, setting);
    ui->plot->axisRect()->setRangeZoom(zoomOrientations);
}

void SequenceDisplay::setOnlyShowMainSequence(bool setting) {
    showOnlyMainSequence = setting;
}

void SequenceDisplay::setSaveControlSequenceToFile(bool setting) {
    saveControlSequenceToFile = setting;
}

void SequenceDisplay::setSaveSensorSignalsToFile(bool setting) {
    saveSensorSignalsToFile = setting;
}

void SequenceDisplay::setAdjustViewOnNewSequence(bool setting) {
    adjustViewOnNewSequence = setting;
}

void SequenceDisplay::setFilenamePrefix(QString newFilenamePrefix) {
    filenamePrefix = newFilenamePrefix;
}

void SequenceDisplay::goToFullView() {
    resetPlotRanges();
}

void SequenceDisplay::updateSignals(double t, double main, double aux)
{
    if (!record) return;
    main_t.push_back(t);
    main_y.push_back(main);
    aux_t.push_back(t);
    aux_y.push_back(aux);
}



/*

const std::vector<lockrect> SequenceDisplay::get_lock_rects() {
    std::vector<lockrect> lock_rects = {};
    enum class State {Unlocked, Locked};
    State state = State::Unlocked;
    if (t.size() != locked.size()) return {};
    if (t.size() != setpoint.size()) return {};
    lockrect current_lock_rect;
    for (size_t i = 0; i < t.size(); ++i) {
        switch (state) {
        case State::Unlocked: {
            if (locked[i]) {
                state = State::Locked;
                current_lock_rect.x1 = t[i];
                current_lock_rect.y1 = - 10.0;
                current_lock_rect.x2 = t[i];
                current_lock_rect.y2 = + 10.0;
                if (current_lock_rect.y1 < setpoint[i]) current_lock_rect.y1 = setpoint[i];
                if (current_lock_rect.y2 > setpoint[i]) current_lock_rect.y2 = setpoint[i];
            }
        } break;
        case State::Locked: {
            current_lock_rect.x2 = t[i];
            if (current_lock_rect.y1 < setpoint[i]) current_lock_rect.y1 = setpoint[i];
            if (current_lock_rect.y2 > setpoint[i]) current_lock_rect.y2 = setpoint[i];
            if (!locked[i]) {
                state = State::Unlocked;
                lock_rects.push_back(current_lock_rect);
            }
        } break;
        }
    }
    return lock_rects;
}

*/

