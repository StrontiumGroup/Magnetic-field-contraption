/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "mfcdecoder.h"
#include <iostream>
#include <sstream>

MFCDecoder::MFCDecoder()
{

}

enum class DecoderState {ChangeChannel, ChannelZero, ChannelOne};

void MFCDecoder::decode_chunk(QByteArray data) {
    for (char c : data) decode(c);
}

void MFCDecoder::decode(const char c) {
    static DecoderState state = DecoderState::ChannelZero;
    static int num_decoded = 0;
    switch (state) {
    case DecoderState::ChangeChannel: {
        if (c == 0) {
            state = DecoderState::ChannelZero;
        } else {
            state = DecoderState::ChannelOne;
        }
    } break;
    case DecoderState::ChannelZero: {
        if (c == 0) {
            state = DecoderState::ChangeChannel;
        } else {
            to_terminal(c);
        }
    } break;
    case DecoderState::ChannelOne: {
        if (c == 0) {
            state = DecoderState::ChangeChannel;
        } else {
            to_data(c);
        }
    } break;
    }
}

void MFCDecoder::to_data(const char c) {
    static std::string databuf = "";
    if ((c == 13) || (c==10)) {
        if (databuf.size() != 0) {
            interpretLineOfData(databuf);
            databuf = "";
        }
    } else {
        databuf += c;
    }
}

void MFCDecoder::to_terminal(const char c) {
    emit terminalUpdated(QString("")+c);
}

void MFCDecoder::interpretLineOfData(const std::string line) {
    /* Turn line into double signal1, double signal2, double position, and bool locked */
    std::istringstream iss(line);
    std::string s;
    std::vector<std::string> results = {};
    while (getline(iss, s, ' ')) results.push_back(s);
    if (results.size() >= 3) {
        const double signal1 = atof(results.at(0).c_str())/1000000.0;
        const double signal2 = atof(results.at(1).c_str())/1000000.0;
        const double position = atof(results.at(2).c_str())/1000000.0;
        emit updateSignals(position, signal1, signal2);
        emit sequencePosition(position);
    }
    if (results.size() >= 4) {
        const double lockstatus = atof(results.at(3).c_str());
        emit lockStatus(lockstatus > 0.5 ? true : false);
    }
    if (results.size() >= 5) {
        const int cpuUse = atof(results.at(4).c_str())/10.0;
        static int divide = 100;
        if (divide -- < 0) {
            emit processorUse(cpuUse);
            divide = 100;
        }
    }
    emit dataLineUpdated(line.c_str());
}

