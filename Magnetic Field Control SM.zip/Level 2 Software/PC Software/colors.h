/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef COLORS_H
#define COLORS_H

#include <QColor>
#include <cmath>

const auto dim = [](const QColor color) -> QColor {
    return QColor(color.red() / 2, color.green() / 2, color.blue() / 2);
};

const auto lerp = [](int x, int y, double t) -> int {
    return (1.0 - t) * x + t * y;
};

const auto darker = [](const QColor color, const double t) -> QColor {
    return QColor(lerp(color.red(), 255, t), lerp(color.green(), 255, t),
        lerp(color.blue(), 255, t));
};

const auto bg_color = QColor(10, 24, 33);
const auto lock_bg_color = QColor(80, 160, 255, 40);
const auto fg_color = QColor(85, 255, 127);
const auto main_color = QColor(255, 255, 255);
const auto aux_color = QColor(255, 220, 0);
const auto lock_color = QColor(255, 40, 0);
const auto offset_color = fg_color;
const auto setpoint_color = QColor(120, 190, 255);

#endif // COLORS_H
