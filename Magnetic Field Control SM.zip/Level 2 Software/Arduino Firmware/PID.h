/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef PID_H
#define PID_H
#include "SignalProcessor.h"
#include "Clock.h"
#include "CLI.h"

class PID : public VirtualDevice, public CLIent
{
public:
    PID(const char *id,
        SignalProcessor &sp,
        CLI &cli);

    int next_sample(int sample_number);

    const char *id;

private:
    double gain_p = 0.0;
    double gain_i = 0.0;
    double gain_d = 0.0;

    /* Inputs */
    int vc_addr_input;
    int vc_addr_offset;
    int vc_addr_setpoint;
    int vc_addr_lock;
    int vc_addr_clk;

    Sample last;
    int last_timestamp;
    Sample time_since_sample;

    /* Outputs */
    int vc_addr_error;
    int vc_addr_integral;
    int vc_addr_derivative;
    int vc_addr_output;

    Sample p_signal, i_signal, d_signal;
    Sample error, output;
};

#endif // PID_H
