/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef AD5781_H
#define AD5781_H

#include "SignalProcessor.h"
#include "CLI.h"

class AD5781 : public VirtualDevice, public CLIent
{
public:
    AD5781(const char* id, const int cs, SignalProcessor &sp, CLI &cli);

    int next_sample(int current_sample);

    const char *id;
    const int cs;
    const int range = 262143;
    const Sample Vrefp = +10.0;
    const Sample Vrefn = -10.0;

    int vc_addr;

protected:

private:
    void initialize_dac();
    int32_t dac_spi_write_and_read(uint8_t *data, uint16_t bytes_number);
    void set_dac_value(uint32_t value);
    uint32_t dac_voltage_to_sample(Sample voltage);

};

#endif // AD5781_H
