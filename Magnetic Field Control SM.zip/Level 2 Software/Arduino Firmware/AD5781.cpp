/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "AD5781.h"
#include <SPI.h>

AD5781::AD5781(const char* id, const int cs, SignalProcessor &sp, CLI &cli)
:   id (id),
    cs (cs),
    VirtualDevice(id, sp, cli),
    CLIent(cli)
{
    cli.cli_fprintf(cli_debug, "AD5781 '%s' @ CS %d\n", id, cs);
    vc_addr = sp.reserve_vc(id, vc_input);
    initialize_dac();
}

int AD5781::next_sample(int current_sample)
{
    set_dac_value(dac_voltage_to_sample(sp.vc[vc_addr]));
    return 0;
}

int32_t AD5781::dac_spi_write_and_read(uint8_t *data, uint16_t bytes_number)
{
  int i;

  for (int i = 0; i < bytes_number-1; i ++) {
    data[i] = SPI.transfer(data[i], SPI_CONTINUE);
  }
  data[bytes_number-1] = SPI.transfer(data[bytes_number-1]);

  return 0;
}

// take anything between 0 and range
void AD5781::set_dac_value(uint32_t value)
{
  uint8_t buf[3];
  buf[0] = 0b00010000;  buf[1] = 0b00000000; buf[2] = 0b00000000; // dac register

  value = value << 2; /* This is a "20 bit" DAC where the last two bits are unused */

  buf[2] |= value & 0xFF;
  buf[1] |= (value/256) & 0xFF;
  buf[0] |= (value/65536) & 0xFF;

  SPI.setDataMode(SPI_MODE1);
  digitalWrite(cs, LOW);
  dac_spi_write_and_read((uint8_t *)(&buf), 3);
  digitalWrite(cs, HIGH);
}

/* TODO: dither */
uint32_t AD5781::dac_voltage_to_sample(Sample voltage) {
    int N = (range + 1) * (voltage - Vrefn) / (Vrefp - Vrefn);
    if (N > range) N = range;
    if (N < 0) N = 0;
    return N;
}

void AD5781::initialize_dac() {
  cli.cli_fprintf(cli_debug, "DAC init at CS %d...\n", cs);

  SPI.setDataMode(SPI_MODE1);
  digitalWrite(cs, LOW);

  uint8_t buf[6];
  buf[0] = 0b00011100;  buf[1] = 0b00000000; buf[2] = 0b00000000; // dac register
  /* control register */
  buf[3] = 0b00100000; /* address */
  buf[4] = 0b00000000;
  buf[5] = 0b00110010; /* SDO disabled (tristate), offset binary coding,
                          DAC in normal operating mode, output ground clamp removed,
                          internal output amplifier enabled */
  dac_spi_write_and_read((uint8_t *)(&buf), 6);

  digitalWrite(cs, HIGH);
}
