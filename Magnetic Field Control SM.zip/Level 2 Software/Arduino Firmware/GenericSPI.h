/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef GENERIC_SPI_H
#define GENERIC_SPI_H
#include <stdint.h>

typedef struct {
    int cs;
} spi_desc;

typedef struct {
  int max_speed_hz;
  uint8_t chip_select;
  uint8_t mode;
  uint8_t id;
  uint8_t type;
} spi_init_param;

extern int32_t spi_init(spi_desc **desc,
     const spi_init_param *param);

extern int32_t spi_remove(spi_desc *desc);

extern int32_t spi_write_and_read(spi_desc *desc,
         uint8_t *data,
         uint16_t bytes_number);

#define SETTING_SPI_MODE_3 0
#define GENERIC_SPI 0

#endif // GENERIC_SPI_H
