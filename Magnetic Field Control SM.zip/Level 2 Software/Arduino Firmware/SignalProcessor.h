/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef SIGNALPROCESSOR_H
#define SIGNALPROCESSOR_H

#include "CLI.h"
#include <vector>

#define vc_off 0
#define vc_input 1
#define vc_output 2

class SignalProcessor;

typedef double Sample;

/*
class Sample {
    double val;
};
*/

class VirtualDevice {
public:
    VirtualDevice (
        const char *id,
        SignalProcessor &sp,
        CLI &cli
    );

    SignalProcessor &sp;
    virtual int next_sample(int sample_number) = 0;
    int starting_vc;
    const char *id;
};

class SignalProcessor : public CLIent
{
    public:
        SignalProcessor(int vc_number, CLI &cli);
        virtual ~SignalProcessor();
        int next_sample();
        int sample_number;
        void register_device(VirtualDevice *dev);

        unsigned long (*profiler_func)();
        int interrupt_time;

        int reserve_vc(const char *label, int type);
        void update_vc(int which, Sample value);
        int find_vc(const char *name);
        const int vc_number;
        Sample *vc;
        int *sends;
        const char **vc_labels;
        int *vc_timestamps;
        int *vc_types;
        const char *type_labels[3] = {"--", "in", "out"};

    protected:
        std::vector<VirtualDevice *> devices;
        std::vector<int> profiler_data;

    private:
        void register_with_cli();
        void display_sends(int which);
        void cli_vc(int argc, char **argv);
        void cli_vcu(int argc, char **argv);
        void cli_send(int argc, char **argv);
        int vcs_used;
};

#endif // SIGNALPROCESSOR_H
