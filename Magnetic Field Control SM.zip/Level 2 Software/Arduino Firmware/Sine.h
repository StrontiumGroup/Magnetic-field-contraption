/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef SINE_H
#define SINE_H
#include "SignalProcessor.h"
#include "CLI.h"

#define __SINE_TABLE_LEN 100

class Sine : public VirtualDevice, public CLIent
{
public:
    Sine(
        const char *id,
        SignalProcessor &sp,
        CLI &cli
    );

    int next_sample(int sample_number);

    /* Note, phi is in units of 2 pi */
    double A, phi, freq;

private:
    int vc_addr_t;
    int vc_addr_output;
    double sines[__SINE_TABLE_LEN];
};

#endif // SINE_H
