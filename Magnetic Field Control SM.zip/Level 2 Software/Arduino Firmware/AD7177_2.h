/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef AD7177_2_H
#define AD7177_2_H

#include "SignalProcessor.h"
#include "CLI.h"
#include "ad717x.h"

class AD7177_2 : public VirtualDevice, public CLIent
{
public:
    AD7177_2(const char *id,
             const int cs,
             const double reqd_rate,
             const int reqd_active_channels[8],
             SignalProcessor &sp,
             CLI &cli);

    struct sample_rate_def {
        int id;
        double rate;
    };

    struct sample_rate_def AD7177_2_sample_rates[21] = {
        {0, 250000}, {1, 125000}, {2, 62500}, {3, 50000}, {4, 31250},
        {5, 25000},  {6, 15625},  {7, 10000}, {8, 5000},  {9, 2500},
        {10, 1000},  {11, 500},   {12,397.5}, {13, 200},  {14, 100},
        {15, 59.92}, {16,49.96},  {17, 20},   {18, 16.66},{19, 10},
        {20, 5}
    };

    void register_with_cli();

    Sample adc_sample_to_voltage(int sample);

    int next_sample(int sample_number);
    void new_sample_rate(double new_rate);
    void restart();

    const char *id;
    const int cs;
    double sample_rate;
    int active_channels[2];

private:
    int vc_addr[2];
    int which_sample_rate; /* Sample rate ID selected for chip configuration */
    int which_channel;
    int adc_status_register;
    int needs_restart = 0;
    int sample;
    int configure(double reqd_rate, const int reqd_active_channels[8]);
    int setup_adc_conf(); /* Configures ADC for use */

    ad717x_dev *adc;
    ad717x_st_reg *pReg;
};

#endif
