/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "LEDIndicator.h"

LEDIndicator::LEDIndicator()
{
    pinMode(LED_USB, OUTPUT);
    pinMode(LED_WAIT, OUTPUT);
    pinMode(LED_SAMPLE, OUTPUT);
    pinMode(LED_CMD, OUTPUT);
    pinMode(LED_LOCK, OUTPUT);
    pinMode(LED_ERROR, OUTPUT);

    test();
    on(LED_USB);
}

LEDIndicator::~LEDIndicator()
{
    //dtor
}

void LEDIndicator::test() {
    int the_delay = 5;
    on(LED_USB);
    on(LED_WAIT);
    on(LED_SAMPLE);
    on(LED_CMD);
    on(LED_LOCK);
    on(LED_ERROR);
    delay(the_delay);
    off(LED_USB);
    off(LED_WAIT);
    off(LED_SAMPLE);
    off(LED_CMD);
    off(LED_LOCK);
    off(LED_ERROR);
}

void LEDIndicator::on(int which) {
    digitalWrite(which, HIGH);
}

void LEDIndicator::off(int which) {
    digitalWrite(which, LOW);
}
