/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "Sequencer.h"

Sequencer::Sequencer(
    const char *id,
    const int no_analog,
    const int no_digital,
    const int max_data_len,
    SignalProcessor &sp,
    CLI &cli
)
:   VirtualDevice(id, sp, cli), CLIent(cli),
    no_analog(no_analog), no_digital(no_digital), max_data_len(max_data_len)
{
    cli.cli_fprintf(cli_debug,
        "Sequencer '%s', %d analog channel(s), %d digital channel(s), max %d data\n",
        id, no_analog, no_digital, max_data_len);

    analog_data = new double*[no_analog];
    digital_data = new double*[no_digital];

    time_data = new double[max_data_len];

    for (int i = 0; i < no_analog; i ++)
        analog_data[i] = new double[max_data_len];

    for (int i = 0; i < no_digital; i ++)
        digital_data[i] = new double[max_data_len];

    cli.register_command({
        .name =
            cli.create_name("%s.data.t", id),
        .description =
            "Upload sequencer time data",
        .help = cli.create_name(""
            "Usage:\n\n"
            "    %s.data.time                       display data\n"
            "    %s.data.time [t0] [t1] [t2]...     set data\n", id, id),
        .fun_ptr = *new std::function<void(int, char**)>
            ([&, max_data_len](int argc, char **argv)
        {
            if (argc == 1) {
                for (int i = 0; i < data_len; i ++)
                    cli.cli_fprintf(cli_stdout, "%f\n", time_data[i]);
                return;
            }
            if (argc > 1) {
                /* check number of data */
                if (argc - 1 > max_data_len) {
                    cli.cli_fprintf(cli_stderr, "Too many data.\n");
                    return;
                }

                /* Check data correctness */
                double val;
                double previous = -1000000.0;
                for (int i = 0; i < argc - 1; i ++) {
                    if (cli.read_double(argv[i+1], &val) < 0) return;
                    if (previous > val) {
                        cli.cli_fprintf(
                            cli_stderr,
                            "Error: time data must be ordered [%f is greater than %f]\n",
                            previous, val);
                        return;
                    }
                    previous = val;
                }

                for (int i = 0; i < argc - 1; i ++)
                    cli.read_double(argv[i+1], &(time_data[i]));

                data_len = argc - 1;
                seq_start = time_data[0];
                seq_end = time_data[data_len - 1];

                return;
            }
        })
    });

    /* Create data handling functions for each channel's data table */
    for (int ch = 0; ch < no_analog; ch ++)
        cli.register_command({
            .name =
                cli.create_name("%s.data.a%d", id, ch),
            .description =
                "Upload sequencer analog channel data",
            .help = cli.create_name(""
                "Usage:\n\n"
                "    %s.data.a%d                       display data\n"
                "    %s.data.a%d [a0] [a1] [a2]...     set data\n", id, ch, id, ch),
            .fun_ptr = *new std::function<void(int, char**)>
                ([&, ch, max_data_len](int argc, char **argv)
            {
                if (argc == 1) {
                    for (int i = 0; i < data_len; i ++)
                        cli.cli_fprintf(cli_stdout, "%f\n", analog_data[ch][i]);
                    return;
                }
                if (argc > 1) {
                    /* check number of data */
                    if (argc - 1 > max_data_len) {
                        cli.cli_fprintf(cli_stderr, "Too many data.\n");
                        return;
                    }

                    /* Check data correctness */
                    double val;
                    for (int i = 0; i < argc - 1; i ++) {
                        if (cli.read_double_in_range(argv[i+1], &val, -10, 10) < 0)
                            return;
                    }

                    for (int i = 0; i < argc - 1; i ++)
                        cli.read_double_in_range(
                            argv[i+1],
                            &(analog_data[ch][i]),
                            -10.0, +10.0);

                    data_len = argc - 1;

                    return;
                }
            })
        });

    for (int ch = 0; ch < no_digital; ch ++)
        cli.register_command({
            .name =
                cli.create_name("%s.data.d%d", id, ch),
            .description =
                "Upload sequencer digital channel data",
            .help = cli.create_name(""
                "Usage:\n\n"
                "    %s.data.d%d                       display data\n"
                "    %s.data.d%d [d0] [d1] [d2]...     set data (0 or 1 allowed)\n",
                id, ch, id, ch),
            .fun_ptr = *new std::function<void(int, char**)>
                ([&, ch, max_data_len](int argc, char **argv)
            {
                if (argc == 1) {
                    for (int i = 0; i < data_len; i ++)
                        cli.cli_fprintf(cli_stdout, "%f\n", digital_data[ch][i]);
                    return;
                }
                if (argc > 1) {
                    /* check number of data */
                    if (argc - 1 > max_data_len) {
                        cli.cli_fprintf(cli_stderr, "Too many data.\n");
                        return;
                    }

                    /* Check data correctness */
                    int val;
                    for (int i = 0; i < argc - 1; i ++) {
                        if (cli.read_int_in_range(argv[i+1], &val, 0, 1) < 0)
                            return;
                    }

                    for (int i = 0; i < argc - 1; i ++) {
                        cli.read_int_in_range(
                            argv[i+1],
                            &(val),
                            0, 1);

                        digital_data[ch][i] = val;
                    }

                    data_len = argc - 1;

                    return;
                }
            })
        });

    cli.register_command({
        .name =
            cli.create_name("%s.mode", id),
        .description =
            "Sequencer mode [0 = off, 1 = auto loop, 2 = single run]",
        .help = cli.create_name(""
            "Usage:\n\n"
            "    %s.mode                       display current mode\n"
            "    %s.mode 0                     sequencer off\n"
            "    %s.mode 1                     auto loop\n"
            "    %s.mode 2                     single shot\n", id, id, id, id),
        .fun_ptr =*new std::function<void(int, char**)> ([&](int argc, char **argv)
        {
            if (argc == 1) {
                cli.cli_fprintf(cli_stdout, "%d\n", mode);
                return;
            }
            int new_mode;
            if (cli.read_int_in_range(argv[1], &new_mode, 0, 2) < 0) return;
            mode = new_mode;
        })
    });

    cli.register_command({
        .name =
            cli.create_name("%s.rewind", id),
        .description =
            "Change position in sequence",
        .help = cli.create_name(""
            "Usage:\n\n"
            "    %s.rewind                       go to t = 0.0 s\n"
            "    %s.rewind [t]                   go to [t]\n", id, id),
        .fun_ptr = *new std::function<void(int, char**)> ([&](int argc, char **argv)
        {
            if (argc == 1) {
                t = 0.0;
                return;
            }
            double new_pos;
            if (cli.read_double(argv[1], &new_pos) < 0) return;
            t = new_pos;
        })
    });

    /* Virtual channels */
    vc_addr_reset = sp.reserve_vc(cli.create_name("%s.reset", id), vc_input);
    vc_addr_clk = sp.reserve_vc(cli.create_name("%s.clk", id), vc_input);
    vc_addr_analog = new int[no_analog];
    vc_addr_digital = new int[no_digital];
    vc_addr_t = sp.reserve_vc(cli.create_name("%s.t", id), vc_output);
    for (int ch = 0; ch < no_analog; ch ++) {
        vc_addr_analog[ch] = sp.reserve_vc(cli.create_name("%s.a%d", id, ch), vc_output);
    }
    for (int ch = 0; ch < no_digital; ch ++) {
        vc_addr_digital[ch] = sp.reserve_vc(cli.create_name("%s.d%d", id, ch), vc_output);
    }

}

int Sequencer::next_sample(int sample_number) {
    /* Sequencer on? */
    if (mode == 0) {
        return 0;
    }

    /* Push time forward */
    if (seq_end == seq_start) {
        t = seq_start;
    } else {
        t += sp.vc[vc_addr_clk];
        if (t > seq_end) {
            if (mode == 1) {
                t -= (seq_end - seq_start);
            } else {
                t = seq_end;
            }
        }
    }
    sp.update_vc(vc_addr_t, t);

    /* Check if data position needs to be updated */
    /* If t is past the next data point, move */
    if (n < data_len - 1) {
        if (time_data[n+1] <= t)
            n ++;
    }
    /* If t is behind the current data point, rewind */
    if (t < time_data[n]) {
        n = 0;
    }

    /* Calculate analog outputs */
    if (t >= seq_end) {
        for (int ch = 0; ch < no_analog; ch ++)
            sp.update_vc(vc_addr_analog[ch], analog_data[ch][n]);
    } else {
        if (t <= seq_start)
            for (int ch = 0; ch < no_analog; ch ++)
                sp.update_vc(vc_addr_analog[ch], analog_data[ch][0]);
        else
            for (int ch = 0; ch < no_analog; ch ++) {
                Sample dt = time_data[n+1]-time_data[n];
                Sample alpha =
                    (dt >= 0.00001)
                    ? (t-time_data[n])/dt
                    : 0.0;
                sp.update_vc(
                    vc_addr_analog[ch],
                    (1.0-alpha)*analog_data[ch][n]+(alpha)*analog_data[ch][n+1]);
            }
    }

    /* Calculate digital outputs */
    for (int ch = 0; ch < no_digital; ch ++)
        sp.update_vc(vc_addr_digital[ch], digital_data[ch][n]);

    return 0;
}

