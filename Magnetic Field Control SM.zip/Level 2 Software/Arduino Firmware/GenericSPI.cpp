/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "Arduino.h"
#include <stdio.h>
#include <SPI.h>
#include "ad717x.h"
#include "GenericSPI.h"

#define SUCCESS 0
#undef DISPLAY_ADC_SPI_COMMANDS

/******************************************************************************/
/************************ Functions Definitions *******************************/
/******************************************************************************/

/**
 * @brief Initialize the SPI communication peripheral.
 * @param desc - The SPI descriptor.
 * @param param - The structure that contains the SPI parameters.
 * @return SUCCESS in case of success, FAILURE otherwise.
 */
int32_t spi_init(spi_desc **desc,
     const spi_init_param *param)
{
    //printf("Entering spi_init with CS = %d\n", param->chip_select);
    *desc = (spi_desc *)malloc(sizeof(spi_desc));
    (*desc)->cs = param->chip_select;
    pinMode(param->chip_select, OUTPUT);
    digitalWrite(param->chip_select, HIGH);
    return SUCCESS;
}

/**
 * @brief Free the resources allocated by spi_init().
 * @param desc - The SPI descriptor.
 * @return SUCCESS in case of success, FAILURE otherwise.
 */
int32_t spi_remove(spi_desc *desc)
{
  printf("entering spi_remove\n");

  if (desc) {
    // Unused variable - fix compiler warning
  }

  return SUCCESS;
}


/**
 * @brief Write and read data to/from SPI.
 * @param desc - The SPI descriptor.
 * @param data - The buffer with the transmitted/received data.
 * @param bytes_number - Number of bytes to write/read.
 * @return SUCCESS in case of success, FAILURE otherwise.
 */
int32_t spi_write_and_read(spi_desc *desc,
         uint8_t *data,
         uint16_t bytes_number)
{
  int i;

#ifdef DISPLAY_ADC_SPI_COMMANDS
  printf("[CS %d] Write %d bytes: ", desc->cs, bytes_number);
  for (i = 0; i < bytes_number; i ++) {
     printf("%0.2x ", data[i]);
  }
#endif

  SPI.setDataMode(SPI_MODE3);
  digitalWrite(desc->cs, LOW);
  SPI.transfer(data, bytes_number);
  digitalWrite(desc->cs, HIGH);

#ifdef DISPLAY_ADC_SPI_COMMANDS
  printf("   <----->   read ", bytes_number);
  for (i = 0; i < bytes_number; i ++) {
      printf("%0.2x ", data[i]);
  }
  printf("\n");
#endif

  return SUCCESS;
}
