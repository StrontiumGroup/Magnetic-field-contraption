/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "CalibrationRelay.h"
#include "Arduino.h"
#include "CLI.h"

CalibrationRelay::CalibrationRelay(int starting_state, CLI &cli)
    : CLIent(cli)
{
    pinMode(A0, OUTPUT);
    pinMode(A1, OUTPUT);
    pinMode(A2, OUTPUT);
    pinMode(A3, OUTPUT);

    set_state(starting_state);

    cli.register_command({
        .name =
            "calibrate",
        .description =
            "Calibration mode (-1 normal, 0..2 DAC selection)",
        .help =
            "Usage:\n"
            "   calibrate -1        -- normal operation\n"
            "   calibrate [dac]     -- choose DAC [dac] for calibration:\n"
            "                          send DAC signal to all ADC inputs\n"
            "                          and voltmeter output.\n",
        .fun_ptr = CLILambda({
            if (argc < 2) {
                cli.cli_fprintf(cli_stderr, "Need parameter.\n");
                return;
            }
            int state;
            if (sscanf(argv[1], "%d", &state) != 1) {
                cli.cli_fprintf(cli_stderr, "Mangled state parameter: %s\n", argv[1]);
                return;
            }
            set_state(state);
        })
    });
}

void CalibrationRelay::switch_to(int new_state) {
    if (new_state != state)
        set_state(new_state);
}

void CalibrationRelay::set_state(int new_state) {
    state = new_state;

    uint8_t dac_select;
    dac_select = (state < 0 ? 0b111 : state);

    digitalWrite(A0, bitRead(dac_select, 0));
    digitalWrite(A1, bitRead(dac_select, 1));
    digitalWrite(A2, bitRead(dac_select, 2));
    digitalWrite(A3, state == -1 ? 0 : 1);

    if (state < 0) {
        cli.cli_fprintf(cli_stdout,
                        "Calibration relays: MFC in normal operation. \n");
    } else {
        cli.cli_fprintf(cli_stdout,
                        "Calibration relays: calibration using DAC %d. \n", state);
    }

}
