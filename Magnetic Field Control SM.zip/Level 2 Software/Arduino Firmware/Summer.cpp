/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "Summer.h"

Summer::Summer(
        const char *id,
        const int no_inputs,
        SignalProcessor &sp,
        CLI &cli
    )
:   VirtualDevice(id, sp, cli), CLIent(cli), no_inputs(no_inputs)
{
    cli.cli_fprintf(cli_debug,
        "Summer '%s', %d input channel(s)\n",
        id, no_inputs);

    vc_addr_inputs = new int[no_inputs];
    for (int i = 0; i < no_inputs; i ++)
        vc_addr_inputs[i] = sp.reserve_vc(cli.create_name("%s.input%d", id, i), vc_input);

    vc_addr_output = sp.reserve_vc(cli.create_name("%s.output", id), vc_output);
}

int Summer::next_sample(int sample_number) {
    Sample sum = 0;
    for (int i = 0; i < no_inputs; i++)
        sum += sp.vc[vc_addr_inputs[i]];

    sp.update_vc(vc_addr_output, sum);
    return 0;
}
