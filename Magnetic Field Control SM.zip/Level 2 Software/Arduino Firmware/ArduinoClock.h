/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef ARDUINOCLOCK_H
#define ARDUINOCLOCK_H

#include "SignalProcessor.h"
#include "Clock.h"

class ArduinoClock : public Clock, public CLIent
{
    public:
        ArduinoClock(SignalProcessor &sp, CLI &cli);
        ~ArduinoClock();
        int tic();
        int toc_microseconds(int _toc);
        double toc_seconds(int _toc);
        int next_sample(int sample_number);
        int previous_time;
        double elapsed;
        int elapsed_us;

    protected:

    private:
        int vc_reset, vc_clk, vc_elapsed;
};

#endif // ARDUINOCLOCK_H
