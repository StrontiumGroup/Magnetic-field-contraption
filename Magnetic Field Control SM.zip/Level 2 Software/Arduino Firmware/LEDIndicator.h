/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef LEDINDICATOR_H
#define LEDINDICATOR_H

#define LED_USB (31)
#define LED_WAIT (30)
#define LED_SAMPLE (29)
#define LED_CMD (28)
#define LED_LOCK (27)
#define LED_ERROR (26)

#include <Arduino.h>

class LEDIndicator
{
    public:
        LEDIndicator();
        virtual ~LEDIndicator();
        void test();
        void on(int which);
        void off(int which);

    protected:

    private:
};

#endif // LEDINDICATOR_H
