/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "ExternalClock.h"
#include <Arduino.h>

#define register_strobe_pin 41
int pins[] = {40, 39, 38, 37, 36, 35, 34, 33, 44, 45, 46, 47, 48, 49, 50, 51}; // from MSB (left) to LSB (right)!

uint16_t read_clock_counter();

ExternalClock::ExternalClock(SignalProcessor &sp, CLI &cli)
: Clock(2000000, "ExternalClock", sp, cli),
CLIent(cli)
{
    pinMode(register_strobe_pin, OUTPUT);

    for (int i = 0; i < sizeof(pins)/sizeof(pins[0]); i ++)
        pinMode(pins[i], INPUT);

    previous_time = read_clock_counter();
    elapsed = 0.0;
    elapsed_us = 0;

    /* VC addresses */
    vc_reset = sp.reserve_vc("ExternalClock.reset", vc_input);
    vc_clk = sp.reserve_vc("ExternalClock.clk", vc_output);
    vc_elapsed = sp.reserve_vc("ExternalClock.elapsed", vc_output);

    cli.register_variable({
        .name = cli.create_name("%s.elapsed", id),
        .description = "Elapsed time (s)",
        .vartype = VARTYPE_DOUBLE,
        .ptr = &elapsed
    });

    cli.register_variable({
        .name = cli.create_name("%s.elapsed_us", id),
        .description = "Elapsed time (us)",
        .vartype = VARTYPE_INT,
        .ptr = &elapsed_us
    });

    cli.register_command({
        .name = "ExternalClock.reset",
        .description = "reset",
        .help = "just run",
        .fun_ptr = CLILambda({elapsed = 0.0;})
    });

}

ExternalClock::~ExternalClock()
{
    //dtor
}

int ExternalClock::tic()
{
    return previous_time;
}

int ExternalClock::toc_microseconds(int _tic)
{
    return previous_time - _tic;
}

double ExternalClock::toc_seconds(int _tic)
{
    return toc_microseconds(_tic) / 1000000.0;
}

int ExternalClock::next_sample(int sample_number)
{
    uint16_t new_time = read_clock_counter();
    uint16_t time_past = new_time-previous_time;
    Sample clock_signal = time_past / 2000000.0;
    elapsed += clock_signal;
    elapsed_us += (new_time-previous_time)/2.0;

    previous_time = new_time;

    if (sp.vc[vc_reset] > 0.9) {
        elapsed = 0.0;
        elapsed_us = 0.0;
    }

    sp.update_vc(vc_clk, clock_signal);
    sp.update_vc(vc_elapsed, elapsed);

    /* update the output too */
    return 0;
}

/* Reads the 16 bits from the two 74HC590 couters */
uint16_t read_clock_counter() {
  uint16_t value = 0;
  /* Strobe the registers */
  digitalWrite(register_strobe_pin, HIGH);
  digitalWrite(register_strobe_pin, LOW);
  /* Read the value */
  for (int i = 0; i < sizeof(pins)/sizeof(pins[0]); i++) {
    value *= 2;
    value += digitalRead(pins[i]);
  }
  return value;
}
