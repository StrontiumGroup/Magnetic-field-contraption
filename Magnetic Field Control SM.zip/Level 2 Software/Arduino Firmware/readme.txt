
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * Code 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * m.borkowski@uva.nl

This folder contains the Arduino firmware used in the Level 2 magnetic field control system. It can only be run on an Arduino Due. Run the file upload.bat to compile and upload to the device. This requires an Arduino installation configured for Arduino Due (on the specific COM port). The device has to be run with *both* USB ports connected for the PC monitor software to work.