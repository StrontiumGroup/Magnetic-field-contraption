/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <Arduino.h>
#include "Monitor.h"
#include <stdio.h>
#include <string.h>

Monitor::Monitor(SignalProcessor &sp, CLI &cli)
:   VirtualDevice("Monitor", sp, cli), CLIent(cli)
{
    cli.register_command({
        .name =
            "monitor",
        .description =
            "Selects virtual channels to monitor",
        .help =
            "Usage:\n"
            "   monitor [vc 1] [vc 2] ...\n",
        .fun_ptr =
            CLIMember(cli_monitor)
    });

    cli.register_variable({
        .name =
            "monitor.mode",
        .description =
            "[0 = all channels per sample, 1 = one channel per sample]",
        .vartype =
            VARTYPE_INT,
        .ptr =
            &mode
    });

    output_func = NULL;
}

Monitor::~Monitor()
{
    //dtor
}

extern char output_buffer[16384];
extern int output_mutex;
extern int interrupt_time;

void monitor_start() {
    /* If available, write CLI output on channel 0 */
    if (!output_mutex) {
        SerialUSB.write((uint8_t)0);
        SerialUSB.write((uint8_t)0);
        SerialUSB.write(output_buffer, strlen(output_buffer));
        sprintf(output_buffer, "");
    }
    /* Write monitor data on channel 1 */
    SerialUSB.write((uint8_t)0);
    SerialUSB.write((uint8_t)1);
}

void monitor_writedouble(double val) {
    SerialUSB.print(val, 6);
    SerialUSB.print(" ");
}

void monitor_puts(const char *buf) {
    SerialUSB.print(buf);
}

int Monitor::next_sample(int sample_number) {
    char buf[256] = "";

    monitor_start();

    if (no_monitored > 0) {
        if (mode == 0) {
            /* Send all channels at once */

            int pos = 0;
            for (int i = 0; i < no_monitored; i++) {
                const int data = 1e6*(sp.vc[monitored_vcs[i]]);
                pos += sprintf(buf + pos, "%d ", data);
            }
            pos += sprintf(buf + pos, "%d %d\n", sp.vc[lock_vc] > 0.5 ? 1 : 0,  interrupt_time);

            SerialUSB.write(buf, strlen(buf));
        } else {
            /* Send one channel per sample and cycle through channels */
            static int current = 0;

            buf[0] = 0;
            int pos = 0;

            pos += sprintf(buf, "%.6lf ", (double)(sp.vc[monitored_vcs[current]]));

            current ++;
            current %= no_monitored;

            if (current == 0)
            pos += sprintf(buf + pos, "\n");

            monitor_puts(buf);
        }
    } else {
        output_func("");
    }
    return 0;
}

void Monitor::cli_monitor(int argc, char **argv) {
    if (argc - 1 > max_monitored) {
        cli.cli_fprintf(
            cli_stderr,
            "Too many channels to monitor, %d is max.\n",
            max_monitored);

        return;
    }

    /* Check that all VCs exist */

    for (int i = 1; i < argc; i ++)
        if (sp.find_vc(argv[i]) < 0) {

            cli.cli_fprintf(
                cli_stderr,
                "Virtual channel not found: %s\n",
                argv[i]);

            return;
        }

    /* Repopulate monitored_vcs and no_monitored */

    no_monitored = 0;

    for (int i = 1; i < argc; i ++)
        monitored_vcs[i-1] = sp.find_vc(argv[i]);

    no_monitored = argc - 1;

    lock_vc = sp.find_vc("pid0.lock");
}
