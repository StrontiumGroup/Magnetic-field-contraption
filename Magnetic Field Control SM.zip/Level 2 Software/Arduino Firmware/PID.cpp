/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "PID.h"

PID::PID(
    const char *id,
    SignalProcessor &sp,
    CLI &cli
)
:   VirtualDevice(id, sp, cli),
    CLIent(cli)
{
    /* Register virtual channels */

    /* Inputs */
    vc_addr_input = sp.reserve_vc(cli.create_name("%s.input", id), vc_input);
    vc_addr_offset = sp.reserve_vc(cli.create_name("%s.offset", id), vc_input);
    vc_addr_setpoint = sp.reserve_vc(cli.create_name("%s.setpoint", id), vc_input);
    vc_addr_lock = sp.reserve_vc(cli.create_name("%s.lock", id), vc_input);
    vc_addr_clk = sp.reserve_vc(cli.create_name("%s.clk", id), vc_input);

    /* Outputs */
    vc_addr_error = sp.reserve_vc(cli.create_name("%s.error", id), vc_output);
    vc_addr_integral = sp.reserve_vc(cli.create_name("%s.integral", id), vc_output);
    vc_addr_derivative = sp.reserve_vc(cli.create_name("%s.derivative", id), vc_output);
    vc_addr_output = sp.reserve_vc(cli.create_name("%s.output", id), vc_output);

    p_signal = 0.0;
    i_signal = 0.0;
    d_signal = 0.0;

    last = sp.vc[vc_addr_input];
    last_timestamp = sp.vc_timestamps[vc_addr_input];
    time_since_sample = 0.000001;

    cli.register_command({
        .name =
            cli.create_name("%s.gains", id),
        .description =
            "Display or modify PID gains parameters",
        .help = cli.create_name(""
            "Usage:\n\n"
            "    %s.gains                       display gain parameters\n"
            "    %s.gains [P] [I] [D]           set gain parameters\n", id, id),
        .fun_ptr = *new std::function<void(int, char**)> ([&](int argc, char **argv)
        {
            if (argc == 1) {
                cli.cli_fprintf(cli_stdout, "%f %f %f\n", gain_p, gain_i, gain_d);
                return;
            }
            if (argc == 4) {
                double new_p, new_i, new_d;
                if (cli.read_double(argv[1],&new_p) != 0) return;
                if (cli.read_double(argv[2],&new_i) != 0) return;
                if (cli.read_double(argv[3],&new_d) != 0) return;
                gain_p = new_p;
                gain_i = new_i;
                gain_d = new_d;
                return;
            }
            cli.cli_fprintf(cli_stderr, "Wrong number of arguments, see help for details.\n");
        })
    });

}

int PID::next_sample(int sample_number) {
    int lock = (sp.vc[vc_addr_lock] >= 1.0 ? 1 : 0);

    /* Error signal */
    error = sp.vc[vc_addr_setpoint] - sp.vc[vc_addr_input];
    sp.update_vc(vc_addr_error, error);

    /* Integral signal */
    i_signal =  lock * (i_signal + gain_i * error * sp.vc[vc_addr_clk]);
    /* Bounds on integral signal */
    i_signal = (i_signal > +10.0 ? 10.0 : i_signal);
    i_signal = (i_signal < -10.0 ? -10.0 : i_signal);
    sp.update_vc(vc_addr_integral, i_signal);

    /* Derivative signal */
    time_since_sample += sp.vc[vc_addr_clk];
    if ((sp.vc_timestamps[vc_addr_input] == sample_number)
        && (sp.vc_timestamps[vc_addr_clk] == sample_number))
    {
        d_signal = (time_since_sample >= 0.00001
                    ? ((error - last)/time_since_sample)
                    : 0.0);

        sp.update_vc(vc_addr_derivative, d_signal);
        last = error;
        last_timestamp = sample_number;
        time_since_sample = 0;
    }

    /* Output signal */
    sp.update_vc(vc_addr_output,
            lock * ( gain_p * error
                   + i_signal /* Gain in the i_signal sits in the integral */
                   + gain_d * d_signal) + sp.vc[vc_addr_offset]);
    return 0;
}
