/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "AD7177_2.h"
#include "GenericSPI.h"
#include "Arduino.h"
#include "LEDIndicator.h"
extern LEDIndicator *led_ptr;

AD7177_2::AD7177_2(
    const char *id,
    const int cs,
    const double reqd_rate,
    const int reqd_active_channels[8],
    SignalProcessor &sp,
    CLI &cli
)
:   id (id),
    cs (cs),
    VirtualDevice(id, sp, cli),
    CLIent(cli)
{
    register_with_cli();

    /* Register virtual channels */
    for (int i = 0; i < 2; i ++)
        vc_addr[i] = sp.reserve_vc(cli.create_name("%s.%d", id, i), vc_off);

    configure(reqd_rate, reqd_active_channels);
}

void AD7177_2::restart() {
    configure(sample_rate, active_channels);
}

int AD7177_2::configure(const double reqd_rate, const int reqd_active_channels[8]) {
    /* Find suitable sample rate */
    which_sample_rate = 0;

    for (int i = 0; i < sizeof(AD7177_2_sample_rates)/sizeof(sample_rate_def); i ++) {
        if (AD7177_2_sample_rates[i].rate >= reqd_rate - 0.001)
            which_sample_rate = i;
    }

    sample_rate = AD7177_2_sample_rates[which_sample_rate].rate;

    for (int i = 0; i < 2; i ++)
        active_channels[i] = reqd_active_channels[i];

    for (int i = 0; i < 2; i ++)
        sp.vc_types[vc_addr[i]] = reqd_active_channels[i] ? vc_output : vc_off;

    /* Configure the device */
    setup_adc_conf();
}

void AD7177_2::new_sample_rate(double new_rate) {
    configure(new_rate, active_channels);
}

int AD7177_2::setup_adc_conf() {
    static ad717x_st_reg AD7177_2_regs[27];
    ad717x_st_reg config[27] = {
        { AD717X_STATUS_REG, 0x00, 1 },
        {
            AD717X_ADCMODE_REG,
            AD717X_ADCMODE_REG_REF_EN | AD717X_ADCMODE_REG_MODE(0),
            2
        },
        {
            AD717X_IFMODE_REG,
            AD717X_IFMODE_REG_DOUT_RESET | AD717X_IFMODE_REG_CRC_EN | AD717X_IFMODE_REG_IOSTRENGTH | AD717X_IFMODE_REG_DATA_STAT,
            2
        },
        { AD717X_REGCHECK_REG, 0x0000, 3},
        { AD717X_DATA_REG, 0x0000, 3 },
        { AD717X_GPIOCON_REG, 0x0000, 2 },
        { AD717X_ID_REG, 0x0000, 2 },
        {
          AD717X_CHMAP0_REG,
          (active_channels[0] ? AD717X_CHMAP_REG_CH_EN | AD717X_CHMAP_REG_AINPOS(0) | AD717X_CHMAP_REG_AINNEG(1) : 0x0000),
          2
        },
        {
          AD717X_CHMAP1_REG,
          (active_channels[1] ? AD717X_CHMAP_REG_CH_EN | AD717X_CHMAP_REG_AINPOS(2) | AD717X_CHMAP_REG_AINNEG(3) : 0x0000),
          2
        },
        { AD717X_CHMAP2_REG, 0x0000, 2 },
        { AD717X_CHMAP3_REG, 0x0000, 2 },
        { AD717X_SETUPCON0_REG, // WAS 0x1320
              AD717X_SETUP_CONF_REG_BI_UNIPOLAR |
              AD717X_SETUP_CONF_REG_AIN_BUF(3) |
              AD717X_SETUP_CONF_REG_REF_BUF(0) |
              AD717X_SETUP_CONF_REG_REF_SEL(0),
          2 },
        { AD717X_SETUPCON1_REG,	0x0000,	2 },
        { AD717X_SETUPCON2_REG, 0x0000,	2 },
        { AD717X_SETUPCON3_REG, 0x0000, 2 },
        {
            AD717X_FILTCON0_REG,
            0x0000 | which_sample_rate,
            2
        },
        {
            AD717X_FILTCON1_REG,
            AD717X_FILT_CONF_REG_ENHFILT(2),
            2
        },
        {
            AD717X_FILTCON2_REG,
            AD717X_FILT_CONF_REG_ENHFILT(2),
            2
        },
        {
            AD717X_FILTCON3_REG,
            AD717X_FILT_CONF_REG_ENHFILT(2),
            2
        },
        { AD717X_OFFSET0_REG, 0, 3 },
        { AD717X_OFFSET1_REG, 0, 3 },
        { AD717X_OFFSET2_REG, 0, 3 },
        { AD717X_OFFSET3_REG, 0, 3 },
        { AD717X_GAIN0_REG, 0, 3 },
        { AD717X_GAIN1_REG, 0, 3 },
        { AD717X_GAIN2_REG, 0, 3 },
        { AD717X_GAIN3_REG, 0, 3 },
    };

    for (int i = 0; i < sizeof(AD7177_2_regs)/sizeof(AD7177_2_regs[0]); i ++) {
        AD7177_2_regs[i] = config[i];
    }

    ad717x_init_param AD7177_2_init;
    AD7177_2_init.spi_init.chip_select = cs;
    AD7177_2_init.spi_init.id = 0;
    AD7177_2_init.spi_init.max_speed_hz = 1000000;
    AD7177_2_init.spi_init.mode = SETTING_SPI_MODE_3;
    AD7177_2_init.spi_init.type = GENERIC_SPI;
    AD7177_2_init.regs = AD7177_2_regs;
    AD7177_2_init.num_regs = sizeof(AD7177_2_regs) / sizeof(AD7177_2_regs[0]);

    while (AD717X_Init(&adc, AD7177_2_init) < 0) {
        /* Something went wrong, try again */
        led_ptr->on(LED_ERROR);
        printf("Problem with AD717X_Init\n");
        delay(100);
        led_ptr->off(LED_ERROR);
    }
    AD717X_ReadRegister(adc, AD717X_STATUS_REG);
    pReg = AD717X_GetReg(adc, AD717X_DATA_REG);
    AD717X_WaitForReady(adc, 1000);
    return 0;
}

void AD7177_2::register_with_cli() {
    cli.register_variable({
        .name =
            cli.create_name("%s.last", id),
        .description =
            "Last sampled channel",
        .vartype =
            VARTYPE_INT,
        .ptr =
            &which_channel
    });

    cli.register_variable({
        .name =
            cli.create_name("%s.status", id),
        .description =
            "ADC status register",
        .vartype =
            VARTYPE_INT,
        .ptr =
            &adc_status_register
    });

    cli.register_variable({
        .name =
            cli.create_name("%s.sample", id),
        .description =
            "ADC raw sample",
        .vartype =
            VARTYPE_INT,
        .ptr =
            &sample
    });

    cli.register_command({
        .name =
            cli.create_name("%s.channels", id),
        .description =
            "(De)activate ADC channels",
        .help = cli.create_name(""
            "Usage:\n\n"
            "   %s.channels          displays current channel configuration\n"
            "   %s.channels x x      [x = 0 is channel deactivated, x = 1 is activated\n"
            "e.g, `%s.channels 1 0' will activate channel 0 and deactivate channel 1.\n",
            id, id, id),
        .fun_ptr = *new std::function<void(int, char**)> ([&](int argc, char **argv)
        {
            if (argc == 1) {
                cli.cli_fprintf(cli_stdout, "%d %d\n", active_channels[0], active_channels[1]);
                return;
            }
            if (argc == 3) {
                /* Verify argument list */
                int new_active_channels[2], ret;
                for (int i = 0; i <2; i ++) {
                    if ((ret = sscanf(argv[i+1], "%d", &new_active_channels[i])) != 1) {
                        cli.cli_fprintf(cli_stderr,
                            "Mangled argument: %s\n", argv[i+1]);
                        return;
                    }
                    if ((new_active_channels[i] != 0) && (new_active_channels[i] != 1)) {
                        cli.cli_fprintf(cli_stderr,
                            "Incorrect value (should be 0 or 1): %s\n", argv[i+1]);
                        return;
                    }
                }
                /* Finally setup */
                for (int i = 0; i < 2; i ++)
                    active_channels[i] = new_active_channels[i];

                needs_restart = 1;

                return;
            }
            cli.cli_fprintf(cli_stderr, "Incorrect number of arguments, check help for details.\n");
        }
        )
    });
}

int AD7177_2::next_sample(int sample_number)
{
    uint32_t sample_as_unsigned;

    if (needs_restart) {
        needs_restart = 0;
        return -1;
    }

    int ret = AD717X_ReadData(adc, (int32_t *)(&sample_as_unsigned));
    if (ret < 0) {
        return ret;
    }

    adc_status_register = (pReg->value)&(0xFF);

    sample = sample_as_unsigned >> 8;
//    printf("%d %d\n", adc_status_register, sample);
    if (adc_status_register & AD717X_STATUS_REG_RDY)
        return 0;

    which_channel = adc_status_register % 16;
    if (active_channels[which_channel])
        sp.update_vc(vc_addr[which_channel], adc_sample_to_voltage(sample));

    return 0;
}

Sample AD7177_2::adc_sample_to_voltage(int sample) {
    return (((double)sample) * 25.0 / 16777215.0) - 12.5;
}
