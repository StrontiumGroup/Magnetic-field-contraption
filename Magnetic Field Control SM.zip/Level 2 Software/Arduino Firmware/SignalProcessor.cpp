/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "SignalProcessor.h"
#include <stdio.h>
#include <string.h>

VirtualDevice::VirtualDevice(
    const char *id,
    SignalProcessor &sp,
    CLI &cli)
    :   id (id), sp (sp)
{
    cli.cli_fprintf(
        cli_debug,
        "New virtual device id = \"%s\"\n",
        id
    );

    sp.register_device(this);
};

SignalProcessor::SignalProcessor(int vc_number, CLI &cli)
:   CLIent(cli), vc_number (vc_number), vcs_used (0), sample_number (0)
{
    profiler_func = NULL;

    sends = new int[vc_number];
    vc = new Sample[vc_number];
    vc_labels = new const char*[vc_number];
    vc_timestamps = new int[vc_number];
    vc_types = new int[vc_number];

    for (int i = 0; i < vc_number; i ++) {
        sends[i] = -1;
        vc[i] = 0.0;
        vc_labels[i] = NULL;
        vc_types[i] = vc_off;
        vc_timestamps[i] = sample_number;
    }

    register_with_cli();
}

int SignalProcessor::reserve_vc(const char *label, int type) {
    int addr = vcs_used;
    vc_labels[addr] = label;
    vc_types[addr] = type;
    cli.cli_fprintf(cli_debug, "new VC %d ", addr);
    display_sends(addr);
    vcs_used ++;
    return addr;
}

SignalProcessor::~SignalProcessor()
{
    delete sends;
    delete vc;
    delete vc_labels;
    delete vc_timestamps;
    delete vc_types;
}

void SignalProcessor::register_with_cli() {
    cli.register_variable({
        .name = cli.create_name("current_sample"),
        .description = "Current sample number",
        .vartype = VARTYPE_INT,
        .ptr = &sample_number
    });

    cli.register_command({
        .name =
            "vd",
        .description =
            "List virtual devices",
        .help =
            "Usage: \n"
            "   vd\n",
        .fun_ptr = CLILambda({
            if (!profiler_func) {
                for (int i = 0; i < devices.size(); i ++)
                    cli.cli_fprintf(
                        cli_stdout,
                        "%d:\t%s\n",
                        i,
                        devices[i]->id
                    );
            } else {
                for (int i = 0; i < devices.size(); i ++)
                    cli.cli_fprintf(
                        cli_stdout,
                        "%d:\t%s [%d us]\n",
                        i,
                        devices[i]->id,
                        i == 0 ? profiler_data[0] : profiler_data[i]-profiler_data[i-1]
                    );
                    cli.cli_fprintf(
                        cli_stdout,
                        "---\n[Total: %d us]\n",
                        devices.size() == 0 ? 0 : profiler_data[devices.size()-1]
                    );

            }
        })
    });

    cli.register_command({
        .name =
            "vc",
        .description =
            "List or find virtual channel by name",
        .help =
            "Usage:\n"
            "    vc\n"
            "    vc [name]\n",
        .fun_ptr =
            CLIMember(cli_vc)
    });

    cli.register_command({
        .name =
            "vcu",
        .description =
            "Read or update the signal on a virtual channel",
        .help =
            "Usage:\n"
            "    vcu                    display all VCs (with timestamps)\n"
            "    vcu [name]             display the value of [name]\n"
            "    vcu [name] [value]     update the value of [name] and its sends\n",
        .fun_ptr =
            CLIMember(cli_vcu)
    });

    cli.register_command({
        .name =
            "send",
        .description =
            "Create sends between virtual channels",
        .help =
            "Usage:\n"
            "    send                   display all defined sends\n"
            "    send [from]            display sends for a single VC\n"
            "    send [from] [to]       establish a send\n"
            "\n"
            "Note: you can only send from an [out] vc to an [in]\n"
            "and daisy-chain [in] channels.\n",
        .fun_ptr =
            CLIMember(cli_send)
    });

    cli.register_array({
        .name =
            "vcs",
        .description =
            "Virtual channels",
        .vartype =
            VARTYPE_DOUBLE,
        .length =
            vc_number,
        .ptr =
            vc});

    cli.register_array({
        .name =
            "vc_timestamps",
        .description =
            "Virtual channels",
        .vartype =
            VARTYPE_INT,
        .length =
            vc_number,
        .ptr =
            vc_timestamps});


    cli.register_array({
        .name =
            "sends",
        .description =
            "Virtual channel sends",
        .vartype =
            VARTYPE_INT,
        .length =
            vc_number,
        .ptr =
            sends});

}

void SignalProcessor::register_device(VirtualDevice *dev)
{
    devices.push_back(dev);
    profiler_data.push_back(0);
}

/* Returns nonzero if anything failed */
int SignalProcessor::next_sample()
{
    sample_number ++;
    int retval = 0;

    if (!profiler_func) {
        for (int i = 0; i < devices.size(); i ++)
            if (devices[i]->next_sample(sample_number) < 0)
                retval = -1;
    } else {
        int tic = profiler_func();
        for (int i = 0; i < devices.size(); i ++) {
            if (devices[i]->next_sample(sample_number) < 0)
                retval = -1;
            profiler_data[i] = profiler_func()-tic;
            interrupt_time = profiler_data[i];
        }
    }

    return retval;
}

void SignalProcessor::update_vc(int which, Sample value) {
    while (vc_timestamps[which] != sample_number) {
        vc[which] = value;
        vc_timestamps[which] = sample_number;
        if ((sends[which] >= 0) && (sends[which] < vc_number))
            which = sends[which];
    }
}

int SignalProcessor::find_vc(const char *name) {
    int which = -1;
    for (int i = 0; i < vc_number; i ++) {
        if (vc_labels[i] == NULL) {
        } else {
            if (strcmp(vc_labels[i], name) == 0)
                which = i;
        }
    }
    return which;
}

void SignalProcessor::display_sends(int which) {
    int been_there[vc_number];
    int n = 0;
    for (int i = 0; i < vc_number; i ++)
        been_there[i] = 0;

    cli.cli_fprintf(cli_stdout, "%s [%s]",
                vc_labels[which],
                type_labels[vc_types[which]]);

    while ((which < vc_number) && (sends[which] >= 0)) {
        if (been_there[sends[which]]) {
            cli.cli_fprintf(cli_stdout, " loop\n");
            return;
        }
        cli.cli_fprintf(cli_stdout, n == 0 ? "\t to: " : ", ");

        cli.cli_fprintf(cli_stdout, "%s [%s]",
                    vc_labels[sends[which]],
                    type_labels[vc_types[sends[which]]]);
        been_there[which] = 1;
        which = sends[which];
        n ++;
    }
    cli.cli_fprintf(cli_stdout, "\n");
}

void SignalProcessor::cli_vc(int argc, char **argv) {
    if (argc == 1) {
        for (int i = 0; i < vc_number; i ++) {
            if (vc_labels[i]) {
                cli.cli_fprintf(cli_stdout, "%d: ", i);
                display_sends(i);
            }
        }
    }
    if (argc == 2) {
        int i;
        if ((i=find_vc(argv[1])) >= 0) {
            display_sends(i);
        } else {
            cli.cli_fprintf(cli_stdout, "Unknown virtual channel %s\n", argv[1]);
        }
    }
}

void SignalProcessor::cli_send(int argc, char **argv) {
    /* List active sends. */
    if (argc == 1)
        for (int i = 0; i < vc_number; i ++)
            if (sends[i] >= 0)
                display_sends(i);
    /* Check for send on specific VC */
    if (argc == 2) {
        int i;
        if ((i = find_vc(argv[1])) >= 0) {
            if ((i < vc_number) && (sends[i] >= 0))
                display_sends(i);
            else
                cli.cli_fprintf(cli_stdout, "%s disconnected.\n", vc_labels[i]);
        } else
            cli.cli_fprintf(cli_stderr, "Unknown virtual channel %s\n", argv[1]);
    }
    if (argc == 3) {
        int a1, a2;
        if ((a1 = find_vc(argv[1])) >= 0) {
            if ((a2 = find_vc(argv[2])) >= 0) {
                if (vc_types[a2] == vc_output) {
                    cli.cli_fprintf(cli_stderr, "Can not send to an output.\n");
                    return;
                }
                /* Check if any other VC has the same send and disconnect it. */
                for (int i = 0; i < vc_number; i ++)
                    if (sends[i] == a2) {
                        cli.cli_fprintf(cli_stdout, "Deleting send from %s to %s.\n", vc_labels[i], vc_labels[sends[i]]);
                        sends[i] = -1;
                    }
                /* Warn that the existing send is deleted */
                if (sends[a1] != -1) {
                    cli.cli_fprintf(cli_stdout, "Deleting send from %s to %s.\n", vc_labels[a1], vc_labels[sends[a1]]);
                }
                /* Create send and display */
                sends[a1] = a2;
                cli_send(2, argv);
            } else {
                if (strcmp(argv[2], "none") == 0) {
                    sends[a1] = -1;
                    cli_send(2, argv);
                } else
                    cli.cli_fprintf(cli_stderr, "Unknown virtual channel %s\n", argv[2]);
            }
        } else {
            cli.cli_fprintf(cli_stderr, "Unknown virtual channel %s\n", argv[1]);
        }
    }
}

void SignalProcessor::cli_vcu(int argc, char **argv) {
    int i;
    if (argc == 1)
        for (i = 0; i < vc_number; i ++)
            if (vc_labels[i])
                cli.cli_fprintf(cli_stdout, "%s: %f [%s, %d]\n",
                                vc_labels[i],
                                vc[i],
                                type_labels[vc_types[i]],
                                vc_timestamps[i]);

    if (argc == 2)
        if ((i = find_vc(argv[1])) != -1)
            cli.cli_fprintf(cli_stdout, "%s: %f\n", vc_labels[i], vc[i]);

    double value;
    if (argc == 3)
        if ((i = find_vc(argv[1])) != -1) {
            if (sscanf(argv[2], "%lf", &value) == 1)
                update_vc(i, value);
            else
                cli.cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[2]);
        } else
            cli.cli_fprintf(cli_stderr, "Unknown virtual channel %s\n", argv[1]);
}
