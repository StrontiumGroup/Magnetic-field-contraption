/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "Sine.h"
#include <math.h>

Sine::Sine(
        const char *id,
        SignalProcessor &sp,
        CLI &cli
    )
:   VirtualDevice(id, sp, cli), CLIent(cli)
{
    cli.cli_fprintf(cli_debug,
        "Sine '%s'\n",
        id);

    A = 0.0;
    phi = 0.0;
    freq = 50.0;

    vc_addr_t = sp.reserve_vc(cli.create_name("%s.t", id), vc_input);
    vc_addr_output = sp.reserve_vc(cli.create_name("%s.output", id), vc_output);

    for (int i = 0; i < __SINE_TABLE_LEN; i ++) {
        sines[i] = sin((2.0*3.1415926*i)/__SINE_TABLE_LEN);
    }

    cli.register_command({
        .name =
            cli.create_name("%s.params", id),
        .description =
            "Set sine parameters",
        .help = cli.create_name(""
            "Usage:\n\n"
            "    %s.params                               display parameters\n"
            "    %s.params [amplitude] [freq] [phase]    set parameters\n\n"
            "where amplitude in [0,10], freq in [0,1000], phase in [0,1].\n", id, id),
        .fun_ptr = *new std::function<void(int, char**)>
            ([&](int argc, char **argv)
        {
            if (argc == 1) {
                cli.cli_fprintf(cli_stdout, "%f %f %f\n", A, freq, phi);
                return;
            }
            if (argc == 4) {
                double new_A, new_freq, new_phi;
                if (cli.read_double_in_range(argv[1], &new_A, 0.0, 10.0) != 0) return;
                if (cli.read_double_in_range(argv[2], &new_freq, 0.0, 1000.0) != 0) return;
                if (cli.read_double_in_range(argv[3], &new_phi, 0.0, 1.0) != 0) return;
                A = new_A;
                freq = new_freq;
                phi = new_phi;
                return;
            }
            cli.cli_fprintf(cli_stderr, "Wrong number of arguments, see help for details.\n");
        })
    });
}

int Sine::next_sample(int sample_number) {
    Sample result;
    int arg = (sp.vc[vc_addr_t] * freq + phi) * __SINE_TABLE_LEN;
    while (arg < 0) arg += __SINE_TABLE_LEN; /* Solution for negative args */
    sp.update_vc(vc_addr_output, A * sines[arg % __SINE_TABLE_LEN]);
    return 0;
}
