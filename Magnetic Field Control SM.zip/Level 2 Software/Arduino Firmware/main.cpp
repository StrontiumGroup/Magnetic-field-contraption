/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <Arduino.h>
#include <SPI.h>
#include "DueTimer.h"

#include "CLI.h"
#include "SignalProcessor.h"

/* Specific virtual devices */
#include "LEDIndicator.h"
#include "Monitor.h"
#include "AD7175_8.h"
#include "AD7177_2.h"
#include "AD5781.h"
#include "ArduinoClock.h"
#include "ExternalClock.h"
#include "PID.h"
#include "Sequencer.h"
#include "Sine.h"
#include "Summer.h"

#include "CalibrationRelay.h"

#define CS_ADC24 10
#define CS_ADC32 4
#define CS_DAC0 52
#define CS_DAC1 8
#define CS_DAC2 9

void setup() {
    /* Disable SYNC ENABLE pin for ADCs */
    pinMode(13, OUTPUT);
    digitalWrite(13, HIGH);
    pinMode(25, OUTPUT);
    digitalWrite(25, HIGH);

    Serial.begin(57600);
    SerialUSB.begin(9600);
    delay(1000); /* Let the receiver software notice */

    digitalWrite(13, LOW);

    /* Set all chip selects to HIGH */
    const int cs[] = {CS_ADC24, CS_ADC32, CS_DAC0, CS_DAC1, CS_DAC2};
    for (int i = 0; i < sizeof(cs)/sizeof(cs[0]); i ++) {
        pinMode(cs[i], OUTPUT);
        digitalWrite(cs[i], HIGH);
    }

    SPI.begin();
    SPI.setClockDivider(6);
    SPI.setBitOrder(MSBFIRST);
    SPI.setDataMode(SPI_MODE3);

}

extern "C" char* sbrk(int incr);

int freeMemory() {
  char top;
  return &top - reinterpret_cast<char*>(sbrk(0));
}

/* "Fix" the lacking C++ library on Arduino so that lambda expressions work */
void std::__throw_bad_function_call() {}

void my_gets(char *str, CLI &cli) {
    static char last_command[MAX_COMMAND_LENGTH] = "";
    int i = 0;
    bool finished = 0;
    do {
        int serial_avail, usb_avail;
        do {
            /* Wait for character */
            serial_avail = Serial.available();
            usb_avail = SerialUSB.available();
        } while (serial_avail + usb_avail == 0);
        /* Get data from either port */
        char c = (serial_avail > 0 ? Serial.read() : SerialUSB.read());
        if ((c >= 32) && (c <= 126)) { /* alphanumerics */
          str[i] = c;
          i ++;
          cli.cli_fprintf(cli_stdout, "%c", c);
        }
        if ((c == 8) || (c==127)) { /* backspace */
          if (i > 0) {
            cli.cli_fprintf(cli_stdout, "%c", c);
            i --;
          }
        }
        if ((c == 10) || (c == 13)) { /* CR or LF */
          if (i > 0) { /* Protection for LF following CR or the other way around  */
            cli.cli_fprintf(cli_stdout, "\n");
            finished = 1;
          }
        }
        if (c == 27) { /* vt100 escape sequence, only up-arrow is implemented */
          while (Serial.available()==0) {
            /* Wait for character */
          }
          if (Serial.read() == '[') {
            while (Serial.available()==0) {
              /* Wait for character */
            }
            if (Serial.read() == 'A') {
              while (i > 0) {
                cli.cli_fprintf(cli_stdout, "%c", 127);
                i --;
              }
              cli.cli_fprintf(cli_stdout, "%s", last_command);
              strcpy(str, last_command);
              i = strlen(str);
            }
          }
        }
    } while (!finished);
    str[i] = 0;
    strcpy((char *)&last_command, str);
}

char output_buffer[16384] = "";
int output_mutex;


SignalProcessor *sp_ptr;
AD7175_8 *adc24_ptr;
AD7177_2 *adc32_ptr;
LEDIndicator *led_ptr;

int interrupt_time;
int interrupt_active = 0;

void interrupt() {
    pinMode(13, OUTPUT);
    digitalWrite(13, HIGH);
    /* Update LEDs */
    led_ptr->off(LED_ERROR);
    led_ptr->off(LED_WAIT);
    led_ptr->on(LED_SAMPLE);
    int tic = micros();

    /* If any of the virtual channels had a problem, restart ADCs. */
    /* Yes, the logic is flawed, but it's only ADCs that can ever need restarting. */
    /* sp_ptr->next_sample(); */

    if (sp_ptr->next_sample() < 0) {
        Timer4.stop();
        adc24_ptr->restart();
        adc32_ptr->restart();
        Timer4.start();
    }

    led_ptr->off(LED_SAMPLE);
    led_ptr->on(LED_WAIT);

    interrupt_time = micros()-tic;
    digitalWrite(13, LOW);
}

void loop() {
    LEDIndicator led;
    led_ptr = &led;
    /* Initialize command line interface */
    CLI cli(

        /* prompt function */
        [&]()->const char*{
            static char prompt[48];
            snprintf((char*)&prompt, 48,
                     "[%d us : %d B >",
                     interrupt_time, freeMemory());
            return (const char *)&prompt;
        },

        /* getline function */
        [&]()->const char *
        {
            static char input_buffer[4096];
            my_gets((char *)&input_buffer, cli);
            return (char *)&input_buffer;
        },

        /* printout function */
        [&](const char *str, int dest)->int
        {
            if (dest == 3) return 0; /* Skip debug information */

            Serial.print(str);
            /* Also send a copy over USB to monitoring software */
            if (interrupt_active) {
                output_mutex = 1;
                if (strlen(str)+strlen(output_buffer) < sizeof(output_buffer))
                    strcat(output_buffer, str);
                output_mutex = 0;
            } else {
                if (strlen(str)+strlen(output_buffer) < sizeof(output_buffer))
                    strcat(output_buffer, str);
                SerialUSB.write((uint8_t)0);
                SerialUSB.write((uint8_t)0);
                SerialUSB.write(output_buffer, strlen(output_buffer));
                sprintf(output_buffer, "");
            }
            return 0;
        }
    );

    /* Start signal processor */
    SignalProcessor sp(200, cli);
    sp.profiler_func = micros;
    sp_ptr = &sp; /* Pointer to be used by interrupt */

    ArduinoClock ac(sp, cli);
    ExternalClock ec(sp, cli);

    /* Initialize calibration relays for normal operation */
    CalibrationRelay cr(-1, cli);

    /*  MFCv3 requires that DACs are initialized first,
        or communications with ADCs will not work.      */
    AD5781 dac0("dac0", CS_DAC0, sp, cli);
    AD5781 dac1("dac1", CS_DAC1, sp, cli);
    AD5781 dac2("dac2", CS_DAC2, sp, cli);

    double sample_rate = 1000.0;

    AD7177_2 adc32("adc32", CS_ADC32, sample_rate,
                   (const int[2]){1, 1}, sp, cli);


    AD7175_8 adc24("adc24", CS_ADC24, sample_rate,
                   (const int[8]){1, 0, 0, 0, 0, 0, 0, 0}, sp, cli);

//    sample_rate = adc24.sample_rate;
    sample_rate = 1000.0;
    adc24_ptr = &adc24;
    adc32_ptr = &adc32;

    /* Provide a sample rate switcher */
    const int valid_sample_rates[] =
        {10000, 5000, 2500, 1000, 500, 200, 100, 20, 10};
    cli.register_command({
        .name =
            "sample_rate",
        .description =
            "Display or change sample rate",
        .help =
            "Usage:\n"
            "   sample_rate             display the current sample rate\n"
            "   sample_rate [new rate]  set new sample rate\n\n"
            "Note: the rates are 10000, 5000, 2500, 1000, 500, 200, 100, 20, and 10 Hz.\n",
        .fun_ptr = CLILambda({
            if (argc == 1) {
                cli.cli_fprintf(cli_stdout, "Current sample rate: %d Hz.\n", (int)sample_rate);
                return;
            }

            int val;

            if (sscanf(argv[1], "%d", &val) != 1) {
                cli.cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[1]);
                return;
            }

            int is_valid = 0;
            for (int i = 0; i < 9; i ++)
                if (val == valid_sample_rates[i]) is_valid = 1;

            if (!is_valid) {
                cli.cli_fprintf(cli_stderr, "Invalid sample rate: %d Hz\n", val);
                cli.cli_fprintf(cli_stderr, "Use 10000, 5000, 2500, 1000, 500, 200, 100, 20, or 10 Hz.\n");
                return;
            }

            Timer4.stop();
            adc24.new_sample_rate(val);
//            adc32.new_sample_rate(val);
            Timer4.setFrequency(val);
            sample_rate = val;
            Timer4.start();
        })
    });

    /* Register the "start" and "stop" commands */
    cli.register_command({
        .name =
            "start",
        .description =
            "Start signal processor interrupt",
        .help =
            "Usage:\n"
            "   start\n",
        .fun_ptr = CLILambda({
            Timer4.start();
            interrupt_active = 1;
        })
    });

    cli.register_command({
        .name =
            "stop",
        .description =
            "Start signal processor interrupt",
        .help =
            "Usage:\n"
            "   stop\n",
        .fun_ptr = CLILambda({
            interrupt_active = 0;
            Timer4.stop();
            SerialUSB.write((uint8_t)0);
            SerialUSB.write((uint8_t)0);
            SerialUSB.write(output_buffer, strlen(output_buffer));
            sprintf(output_buffer, "");
        })
    });

    /* Monitor output via Native USB port */
    Monitor mon(sp, cli);

    /* Currently one hardcoded PID */
    PID pid0("pid0", sp, cli);

    /* Similarly hardcoded one Sequencer */
    Sequencer seq0("seq0", 2, 1, 100, sp, cli);

    /* Sinewave generator */
    Sine sin0("sin0", sp, cli);

    /* Summer to sum the pid and sine signals */
    Summer sum0("sum0", 2, sp, cli);

    /* Start monitoring */

    cli.execute_command("monitor adc24.3 adc24.0 seq0.t");

    /* Install timer */
    cli.cli_fprintf(cli_debug, "Installing timer at sample rate %f\n", sample_rate);

    Serial.flush();
    SerialUSB.flush();
    delayMicroseconds(1500);
    Timer4.attachInterrupt(interrupt);
    Timer4.setFrequency(sample_rate);
    /* Enable SYNC ENABLE pin for ADCs */
    digitalWrite(25, LOW);
    Timer4.start();
    interrupt_active = 1;

    led.off(LED_CMD);
    /* Run command line interface */
    cli.loop();
}
