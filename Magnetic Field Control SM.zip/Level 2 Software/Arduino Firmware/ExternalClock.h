/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef EXTERNALCLOCK_H
#define EXTERNALCLOCK_H

#include "SignalProcessor.h"
#include "Clock.h"

class ExternalClock : public Clock, public CLIent
{
    public:
        ExternalClock(SignalProcessor &sp, CLI &cli);
        virtual ~ExternalClock();
        int tic();
        int toc_microseconds(int _toc);
        double toc_seconds(int _toc);
        int next_sample(int sample_number);
        uint16_t previous_time;
        double elapsed;
        int elapsed_us;

    protected:

    private:
        int vc_reset, vc_clk, vc_elapsed;
};

#endif // EXTERNALCLOCK_H
