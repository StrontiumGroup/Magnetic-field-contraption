/*
 * M. Borkowski, L. Reichsoellner, P. Thekkeppatt, V. Barbe,
 * T. van Roon, N. J. van Druten, F. Schreck
 *
 * Active stabilization of kilogauss magnetic fields to the ppm level
 * for magnetoassociation on ultranarrow Feshbach resonances
 * Rev. Sci. Instrum. 2023
 *
 * 2020-2021 Mateusz Borkowski, University of Amsterdam, The Netherlands
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "CLI.h"

CLI::CLI()
    : command_num {0}, variable_num {0}, array_num {0},
      cli_prompt_func {[]()->const char * {
          return ">";
      }},
      cli_getline {[&]()->char * {
          static char input_buffer[2048];
          fgets((char *)&input_buffer, 2048, stdin);
          input_buffer[strlen(input_buffer)-1] = 0;
          return (char *)&input_buffer;
      }},
      cli_fputs ([&](const char *buf, int dest)->int {
          return cli_fputs_builtin(buf, dest);
    })
{
    cli_fprintf(cli_debug, "CLI initializing...\n");
    register_builtins();
    cli_fprintf(cli_debug, "CLI init done.\n");
}

CLI::CLI(
        std::function<const char *(void)> cli_prompt_func,
        std::function<const char *(void)> cli_getline,
        std::function<int(const char *, int)> cli_fputs
    )
    : command_num {0}, variable_num {0}, array_num {0},
      cli_prompt_func {cli_prompt_func},
      cli_getline {cli_getline},
      cli_fputs {cli_fputs}
{
    cli_fprintf(cli_debug, "CLI initializing...\n");
    register_builtins();
    cli_fprintf(cli_debug, "CLI init done.\n");
}

void CLI::register_builtins()
{
    register_command({
        .name =
            "help",
        .description =
            "Lists all commands or gives detailed info for a command.",
        .help =
            "Usage:\n"
            "    help\n"
            "    help [command name]\n",
        .fun_ptr = CLILambda(
        {
            if (argc == 1) {
                for (int i = 0; i < command_num; i ++) {
                    cli_fprintf(cli_stdout, "\t%s\t%s\n", commands[i].name, commands[i].description);
                }
                cli_fprintf(cli_stdout,
                    "%d commands total. Type \"help [command]\" for more details.\n",
                    command_num);
            } else {
                int num_command = find_command(argv[1]);
                if (num_command < 0) {
                    cli_fprintf(cli_stderr, "No such command: %s\n", argv[1]);
                } else {
                    cli_fprintf(cli_stdout, "%s\t%s\n%s\n", commands[num_command].name, commands[num_command].description, commands[num_command].help);
                }
            }
        })
    });

    register_command({
        .name =
            "set",
        .description =
            "Set or get variables [see help].",
        .help =
            "Usage:\n"
            "    set                    list all variables and their values\n"
            "    set [varname]          display the value of [varname],\n"
            "    set [varname] [value]  set the value of [varname]\n",
        .fun_ptr = CLILambda(
        {
            if (argc == 1) {
                for (int i = 0; i < variable_num; i ++) {
                    cli_fprintf(cli_stdout, "%s = ", variables[i].name);
                    print_variable(i);
                    cli_fprintf(cli_stdout, " \t%s\n", variables[i].description);
                }
            }
            if (argc == 2) {
                int i = find_variable(argv[1]);
                if (i < 0) {
                    cli_fprintf(cli_stderr, "No such variable: %s\n", argv[1]);
                } else {
                    print_variable(i);
                    cli_fprintf(cli_stdout, "\n");
                }
            }
            if (argc >= 3) {
                int i = find_variable(argv[1]);
                if (i < 0) {
                    cli_fprintf(cli_stderr, "No such variable: %s\n", argv[1]);
                } else {
                    switch(variables[i].vartype) {
                        case VARTYPE_INT: {
                            int testbuf;
                            if (sscanf(argv[2], "%d", &testbuf) != 1) {
                                cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[2]);
                            } else {
                                *((int *)variables[i].ptr) = testbuf;
                            }
                        } break;
                        case VARTYPE_DOUBLE: {
                            double testbuf;
                            if (sscanf(argv[2], "%lf", &testbuf) != 1) {
                                cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[2]);
                            } else {
                                *((double *)variables[i].ptr) = testbuf;
                                //cli_fprintf(cli_stdout, "Value read: from %s to %f %f.\n", argv[2], testbuf, *((double *)variables[i].ptr));
                            }
                        } break;
                    }
                }
            }
        })
    });

    register_command({
        .name =
            "array",
        .description =
            "Set or get arrays [see help]",
        .help =
            "Usage:\n"
            "    array --- \tlist all array names and their length\n"
            "    array [arrayname] \t--- display all values of [arrayname],\n"
            "    array [arrayname] [index] \t--- get the value of [array] at [index]\n"
            "    array [arrayname] [index] [value] \t--- set the value of [array] at [index]\n",
        .fun_ptr = CLILambda(
        {
            if (argc == 1) {
                for (int i = 0; i < array_num; i ++) {
                    cli_fprintf(cli_stdout,
                        "%s \t%d \t%s\n",
                        arrays[i].name,
                        arrays[i].length,
                        arrays[i].description);
                }
            }
            if (argc == 2) {
                int i = find_array(argv[1]);
                if (i < 0) {
                    cli_fprintf(cli_stderr, "No such array: %s\n", argv[1]);
                } else {
                    switch (arrays[i].vartype) {
                        case VARTYPE_INT: {
                            int *data;
                            data = (int *)(arrays[i].ptr);
                            for (int j = 0; j < arrays[i].length; j ++) {
                                cli_fprintf(cli_stdout, "%d\n", data[j]);
                            }
                        } break;
                        case VARTYPE_DOUBLE: {
                            double *data;
                            data = (double *)(arrays[i].ptr);
                            for (int j = 0; j < arrays[i].length; j ++) {
                                cli_fprintf(cli_stdout, "%f\n", data[j]);
                            }
                        } break;
                    }
                }
            }
            if (argc == 3) {
                int i = find_array(argv[1]);
                int index;
                if (i < 0) {
                    cli_fprintf(cli_stderr, "No such array: %s\n", argv[1]);
                } else {
                    if (sscanf(argv[2], "%d", &index) != 1) {
                        cli_fprintf(cli_stderr, "Mangled index: %s\n", argv[2]);
                    } else {
                        switch (arrays[i].vartype) {
                            case VARTYPE_INT: {
                                int *data;
                                data = (int *)(arrays[i].ptr);
                                cli_fprintf(cli_stdout, "%d\n", data[index]);
                            } break;
                            case VARTYPE_DOUBLE: {
                                double *data;
                                data = (double *)(arrays[i].ptr);
                                cli_fprintf(cli_stdout, "%f\n", data[index]);
                            } break;
                        }
                    }
                }
            }
            if (argc >= 4) {
                int i = find_array(argv[1]);
                int index;
                if (i < 0) {
                    cli_fprintf(cli_stderr, "No such array: %s\n", argv[1]);
                } else {
                    if (sscanf(argv[2], "%d", &index) != 1) {
                        cli_fprintf(cli_stderr, "Mangled index: %s\n", argv[2]);
                    } else {
                        switch (arrays[i].vartype) {
                            case VARTYPE_INT: {
                                int *data;
                                data = (int *)(arrays[i].ptr);
                                int testbuf;
                                if (sscanf(argv[3], "%d", &testbuf) != 1) {
                                    cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[3]);
                                } else {
                                    data[index] = testbuf;
                                }
                            } break;
                            case VARTYPE_DOUBLE: {
                                double *data;
                                data = (double *)(arrays[i].ptr);
                                double testbuf;
                                if (sscanf(argv[3], "%lf", &testbuf) != 1) {
                                    cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[3]);
                                } else {
                                    data[index] = testbuf;
                                }
                            } break;
                        }
                    }
                }
            }
        })
    });


    register_command({
        .name =
            "arraylen",
        .description =
            "Set or get length of an array",
        .help =
            "Usage:\n"
            "    arraylen [arrayname] --- get length\n"
            "    arraylen [arrayname] [length] --- set length\n",
        .fun_ptr =
            *new std::function<void(int, char**)> ([&](int argc, char **argv)
            {
                if (argc == 1) {
                    for (int i = 0; i < array_num; i ++) {
                        cli_fprintf(cli_stdout, "%s %d\n", arrays[i].name, arrays[i].length);
                    }
                }
                if (argc == 2) {
                    int i = find_array(argv[1]);
                    if (i < 0) {
                        cli_fprintf(cli_stderr, "No such array: %s\n", argv[1]);
                    } else {
                        cli_fprintf(cli_stdout, "%d\n", arrays[i].length);
                    }
                }
                if (argc >= 3) {
                    int i = find_array(argv[1]);
                    if (i < 0) {
                        cli_fprintf(cli_stderr, "No such array: %s\n", argv[1]);
                    } else {
                        int testbuf;
                        if (sscanf(argv[2], "%d", &testbuf) != 1) {
                          cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[2]);
                        } else {
                          arrays[i].length = testbuf;
                        }
                    }
                }
            })
    });

    register_command({
        .name =
            "arrayb",
        .description =
            "Set an entire array in bulk",
        .help =
            "Usage:\n"
            "    arrayb [arrayname] --- get data\n"
            "    arrayb [arrayname] [data] --- replace all data in array\n",
        .fun_ptr = CLILambda(
        {
            if (argc == 1) {
                for (int i = 0; i < array_num; i ++) {
                    cli_fprintf(cli_stdout, "%s %d\n", arrays[i].name, arrays[i].length);
                }
            }
            if (argc == 2) {
                int i = find_array(argv[1]);
                if (i < 0) {
                    cli_fprintf(cli_stderr, "No such array: %s\n", argv[1]);
                } else {
                    switch (arrays[i].vartype) {
                        case VARTYPE_INT: {
                            int *data;
                            data = (int *)(arrays[i].ptr);
                            for (int j = 0; j < arrays[i].length; j ++) {
                                cli_fprintf(cli_stdout, "%d\n", data[j]);
                            }
                        } break;
                        case VARTYPE_DOUBLE: {
                            double *data;
                            data = (double *)(arrays[i].ptr);
                            for (int j = 0; j < arrays[i].length; j ++) {
                                cli_fprintf(cli_stdout, "%f\n", data[j]);
                            }
                        } break;
                    }
                }
            }
            if (argc >= 3) {
                int i = find_array(argv[1]);
                if (i < 0) {
                    cli_fprintf(cli_stderr, "No such array: %s\n", argv[1]);
                } else {
                  for (int index = 0; index < argc - 2; index ++) {
                    switch (arrays[i].vartype) {
                        case VARTYPE_INT: {
                            int *data;
                            data = (int *)(arrays[i].ptr);
                            int testbuf;
                            if (sscanf(argv[2+index], "%d", &testbuf) != 1) {
                                cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[3]);
                            } else {
                                data[index] = testbuf;
                            }
                        } break;
                        case VARTYPE_DOUBLE: {
                            double *data;
                            data = (double *)(arrays[i].ptr);
                            double testbuf;
                            if (sscanf(argv[2+index], "%lf", &testbuf) != 1) {
                                cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[3]);
                            } else {
                                data[index] = testbuf;
                            }
                        } break;
                    }
                    arrays[i].length = argc-2;
                  }
                }
            }
        })
    });

    register_command({
        .name =
            "append",
        .description =
            "Append a value to array",
        .help =
            "Usage:\n"
            "    append [arrayname] [value]\n",
        .fun_ptr = CLILambda(
        {
            if (argc != 3) {
                cli_fprintf(cli_stderr, "This command takes exactly 2 arguments. Type \"help append\" for more information.\n");
            } else {
                int i = find_array(argv[1]);
                if (i < 0) {
                    cli_fprintf(cli_stderr, "No such array: %s\n", argv[1]);
                } else {
                    int index = arrays[i].length;
                    switch (arrays[i].vartype) {
                        case VARTYPE_INT: {
                            int *data;
                            data = (int *)(arrays[i].ptr);
                            int testbuf;
                            if (sscanf(argv[2], "%d", &testbuf) != 1) {
                                cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[2]);
                            } else {
                                data[index] = testbuf;
                                arrays[i].length++;
                            }
                        } break;
                        case VARTYPE_DOUBLE: {
                            double *data;
                            data = (double *)(arrays[i].ptr);
                            double testbuf;
                            if (sscanf(argv[2], "%lf", &testbuf) != 1) {
                                cli_fprintf(cli_stderr, "Mangled value: %s\n", argv[2]);
                            } else {
                                data[index] = testbuf;
                                arrays[i].length++;
                            }
                        } break;
                    }
                }
            }
        })
    });

    register_command({
        .name =
            "repeat",
        .description =
            "Repeat a command a given number of times.",
        .help =
            "Usage: \n"
            "    repeat [number]\n"
            "followed by the command in the next line.\n",
        .fun_ptr = CLILambda(
        {
            char copy[MAX_COMMAND_LENGTH];
            int number;
            if (argc < 2) {
                cli_fprintf(cli_stderr, "Need the number of repetitions.\n");
                return;
            }
            if (sscanf(argv[1], "%d", &number)!=1) {
                cli_fprintf(cli_stderr, "Mangled argument: %s\n", argv[1]);
                return;
            }
            cli_fprintf(cli_stdout, "command to repeat> ");
            const char *cmd = cli_getline();
            for (int i = 0; i < number; i ++) {
                strcpy(copy, cmd);
                execute_command(copy);
            }
        })
    });

}

CLI::~CLI()
{
    //dtor
}

void CLI::print_variable(int i) {
    switch (variables[i].vartype) {
        case VARTYPE_INT: {
            int val = *((int *)variables[i].ptr);
            cli_fprintf(cli_stdout, "%d", val);
        } break;
        case VARTYPE_DOUBLE: {
            double val = *((double *)variables[i].ptr);
            cli_fprintf(cli_stdout, "%lf", val);
        } break;
    }
}

int CLI::find_variable(char *name) {
    for (int i = 0; i < variable_num; i ++) {
        if (strcmp(name, variables[i].name)==0) return i;
    }
    return -1;
}

int CLI::find_array(const char *name) {
    for (int i = 0; i < array_num; i ++) {
        if (strcmp(name, arrays[i].name)==0) return i;
    }
    return -1;
}

/* Find an array and return the number of its elements */
int CLI::arraylen(const char *arrayname) {
  int i = find_array(arrayname);
  if (i < 0) {
    return i;
  } else {
    return arrays[i].length;
  }
}

/* Find an array and return the number of its elements */
int CLI::setarraylen(const char *arrayname, int len) {
  int i = find_array(arrayname);
  if (i < 0) {
    return i;
  } else {
    arrays[i].length = len;
    return len;
  }
}

int CLI::find_command(char *name) {
    for (int i = 0; i < command_num; i ++) {
        if (strcmp(name, commands[i].name)==0) return i;
    }
    return -1;
}

void CLI::execute_command(const char *command) {
    char str[MAX_COMMAND_LENGTH];
    strcpy((char *)&str, command);
    int argc = 0;
    int num_command;
    char *argv[MAX_PARAMETERS];
    char delim[] = " ";
    char *ptr = strtok(str, delim);
    while(ptr != NULL)
    {
        argv[argc] = ptr;
        argc++;
        ptr = strtok(NULL, delim);
    }
    if (argc>0) {
        num_command = find_command(argv[0]);
        if (num_command < 0) {
            cli_fprintf(cli_stderr, "Bad command \"%s\", type \"help\" for more information.\n", argv[0]);
        } else {
            (commands[num_command].fun_ptr)(argc, argv);
        }
    }
}

int CLI::register_array(struct array_def the_array) {
    cli_fprintf(cli_debug, "CLI:\tRegistering array %d \"%s\" (\"%s\") [%d]\n",
        array_num, the_array.name, the_array.description, the_array.length);
    arrays.push_back(the_array);
    array_num++;
    return array_num-1;
}

int CLI::register_variable(struct variable_def the_variable) {
    cli_fprintf(cli_debug, "CLI:\tRegistering variable %d \"%s\" (\"%s\")\n",
        variable_num, the_variable.name, the_variable.description);
    variables.push_back(the_variable);
    variable_num++;
    return variable_num-1;
}

int CLI::register_command(struct command_def the_command) {
    cli_fprintf(cli_debug, "CLI:\tRegistering command %d \"%s\" (\"%s\")\n",
        command_num, the_command.name, the_command.description);
    commands.push_back(the_command);
    command_num ++;
    return command_num-1;
}

char *CLI::create_name(const char *format, ...) {
    char buffer[1024];
    va_list args;
    va_start (args, format);
    vsnprintf (buffer, 1024, format, args);
    va_end (args);
    char *out = new char [strlen(buffer)+1];
    strcpy(out, buffer);
    return out;
}

int CLI::cli_fprintf(int dest, const char *format, ...) {
    char buffer[1024];
    va_list args;
    va_start (args, format);
    int retval = vsnprintf (buffer, 1024, format, args);
    va_end (args);
    char *out = (char *)&buffer;
    cli_fputs(out, dest);
    return retval;
}

void CLI::loop() {
    while(1) {
        const char *prompt = cli_prompt_func();
        cli_fputs(prompt, cli_stdout);
        const char *cmdline = cli_getline();
        execute_command(cmdline);
    }
}

int CLI::cli_fputs_builtin(const char *buf, int dest) {
    FILE *dest_file[] = {stdin, stdout, stderr, stdout};
    return fprintf(dest_file[dest], buf);
}

int CLI::read_double(const char *str, double *target)
{
    if (sscanf(str, "%lf", target)!=1) {
        cli_fprintf(cli_stderr, "Mangled argument: %s\n", str);
        return -1;
    } else {
        return 0;
    }
}

int CLI::read_double_in_range(const char *str, double *target, double range_min, double range_max)
{
    if (read_double(str, target) < 0) {
        return -1;
    }

    if ((*target < range_min) || (*target > range_max)) {
        cli_fprintf(cli_stderr, "Argument '%s' out of range [%f, %f]\n", str, range_min, range_max);
        return -1;
    }

    return 0;
}

int CLI::read_int(const char *str, int *target)
{
    if (sscanf(str, "%d", target)!=1) {
        cli_fprintf(cli_stderr, "Mangled argument: %s\n", str);
        return -1;
    } else {
        return 0;
    }
}

int CLI::read_int_in_range(const char *str, int *target, int range_min, int range_max)
{
    if (read_int(str, target) < 0) {
        return -1;
    }

    if ((*target < range_min) || (*target > range_max)) {
        cli_fprintf(cli_stderr, "Argument '%s' (%d) out of range [%d, %d]\n", str, *target, range_min, range_max);
        return -1;
    }

    return 0;
}

CLIent::CLIent(CLI &cli)
    : cli (cli)//, prefix (""), no (0)
{
}
